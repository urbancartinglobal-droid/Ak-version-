package com.adai.assistant

import com.adai.assistant.core.ChatMessage
import com.adai.assistant.core.Orchestrator
import com.adai.assistant.core.Prompts
import com.adai.assistant.core.Role
import com.adai.assistant.core.ToolCall
import com.adai.assistant.core.ToolResult
import com.adai.assistant.core.ToolRunner
import com.adai.assistant.core.ToolSpec
import com.adai.assistant.core.AiReply
import com.adai.assistant.ai.AiProvider
import com.adai.assistant.data.Conversation
import com.adai.assistant.data.ConversationStore
import com.adai.assistant.data.ItemStore
import com.adai.assistant.live.NewsParser
import com.adai.assistant.live.WeatherParser
import com.adai.assistant.settings.AppSettings
import com.adai.assistant.tools.AppFinder
import com.adai.assistant.tools.Calc
import com.adai.assistant.tools.OfflineRouter
import com.adai.assistant.voice.SpeechOutput
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class CalcTest {
    @Test fun basic() { assertEquals(10.0, Calc.eval("2+3*2+2"), 1e-9) }
    @Test fun precedenceAndParens() { assertEquals(20.0, Calc.eval("(2+3)*4"), 1e-9) }
    @Test fun percent() { assertEquals(90.0, Calc.eval("500*18%"), 1e-9) }
    @Test fun unaryPower() { assertEquals(-4.0, Calc.eval("-2^2"), 1e-9); assertEquals(0.5, Calc.eval("2^-1"), 1e-9) }
    @Test fun commasAndSymbols() { assertEquals(2500.0, Calc.eval("1,000 × 2.5"), 1e-9) }
    @Test(expected = IllegalArgumentException::class) fun divZero() { Calc.eval("1/0") }
    @Test(expected = IllegalArgumentException::class) fun garbage() { Calc.eval("2+abc") }
    @Test fun format() { assertEquals("90", Calc.format(90.0)); assertEquals("0.333333", Calc.format(1.0 / 3)) }
}

class OfflineRouterTest {
    @Test fun torchOnOff() {
        assertEquals(true, OfflineRouter.route("torch on karo")!!.args.getBoolean("on"))
        assertEquals(false, OfflineRouter.route("torch band karo")!!.args.getBoolean("on"))
        assertEquals(true, OfflineRouter.route("टॉर्च चालू करो")!!.args.getBoolean("on"))
    }
    @Test fun battery() { assertEquals("battery_status", OfflineRouter.route("mere phone ki battery kitni hai?")!!.tool) }
    @Test fun openApp() {
        assertEquals("youtube", OfflineRouter.route("YouTube kholo")!!.args.getString("name"))
        assertEquals("whatsapp", OfflineRouter.route("open WhatsApp")!!.args.getString("name"))
        assertEquals("youtube", OfflineRouter.route("यूट्यूब खोलो")!!.args.getString("name"))
    }
    @Test fun conversationIsNotHijacked() {
        assertNull(OfflineRouter.route("Is topic ko detail mein samjhao"))
        assertNull(OfflineRouter.route("torch kya hota hai aur kaise kaam karta hai bataiye please"))
        assertNull(OfflineRouter.route("Mausam batao"))
    }
}

class AppFinderTest {
    private val apps = listOf(AppFinder.Entry("YouTube Music", "a"), AppFinder.Entry("YouTube", "b"), AppFinder.Entry("Chrome", "c"))
    @Test fun exactBeatsPrefix() { assertEquals("b", AppFinder.pick("youtube", apps)!!.pkg) }
    @Test fun contains() { assertEquals("c", AppFinder.pick("hrom", apps)!!.pkg) }
    @Test fun missing() { assertNull(AppFinder.pick("nonexistent", apps)) }
}

class SpeechHelpersTest {
    @Test fun detectsHindi() { assertEquals("hi-IN", SpeechOutput.detectLanguage("आज मौसम बहुत अच्छा है")) }
    @Test fun detectsEnglish() { assertEquals("en-IN", SpeechOutput.detectLanguage("The weather is nice today")) }
    @Test fun cleansMarkdown() { assertEquals("Hello world link", SpeechOutput.cleanForSpeech("**Hello** `world` https://x.com/a")) }
    @Test fun chunksLongText() {
        val parts = SpeechOutput.chunk("Hello world. ".repeat(600), 3000)
        assertTrue(parts.size > 1); assertTrue(parts.all { it.length <= 3001 })
    }
}

class PromptTest {
    @Test fun containsNameMemoryAndRules() {
        val p = Prompts.system(AppSettings(assistantName = "Zed", homeCity = "Prayagraj"), listOf("User ka naam Amit hai"))
        assertTrue(p.contains("You are Zed")); assertTrue(p.contains("Amit")); assertTrue(p.contains("Prayagraj"))
        assertTrue(p.contains("Never claim an action succeeded"))
    }
}

private class ScriptedProvider(private val replies: List<AiReply>) : AiProvider {
    var calls = 0
    val seen = mutableListOf<List<ChatMessage>>()
    override suspend fun chat(system: String, messages: List<ChatMessage>, tools: List<ToolSpec>): AiReply {
        seen += messages
        return replies[minOf(calls++, replies.size - 1)]
    }
}

private class FakeRunner(val result: ToolResult) : ToolRunner {
    val executed = mutableListOf<ToolCall>()
    override val specs = listOf(ToolSpec("flashlight", "torch"))
    override suspend fun execute(call: ToolCall): ToolResult { executed += call; return result }
}

class OrchestratorTest {
    @Test fun toolLoopThenAnswer() = runBlocking {
        val call = ToolCall("1", "flashlight", JSONObject().put("on", true))
        val provider = ScriptedProvider(listOf(AiReply("", listOf(call)), AiReply("Torch on ho gayi.", emptyList())))
        val runner = FakeRunner(ToolResult.ok("done"))
        val out = Orchestrator(provider, runner).respond("sys", listOf(ChatMessage(Role.USER, "torch on karo")))
        assertEquals(listOf(Role.ASSISTANT, Role.TOOL, Role.ASSISTANT), out.map { it.role })
        assertEquals("OK: done", out[1].text)
        assertEquals("Torch on ho gayi.", out[2].text)
        assertEquals(1, runner.executed.size)
    }

    @Test fun toolErrorIsReportedToModelNotHidden() = runBlocking {
        val call = ToolCall("1", "flashlight", JSONObject())
        val provider = ScriptedProvider(listOf(AiReply("", listOf(call)), AiReply("Nahi ho paaya.", emptyList())))
        val out = Orchestrator(provider, FakeRunner(ToolResult.fail("camera busy"))).respond("s", listOf(ChatMessage(Role.USER, "x")))
        assertEquals("ERROR: camera busy", out[1].text)
        assertTrue(provider.seen.last().any { it.role == Role.TOOL && it.text.startsWith("ERROR") })
    }

    @Test fun runawayLoopIsStopped() = runBlocking {
        val call = ToolCall("1", "flashlight", JSONObject())
        val provider = ScriptedProvider(listOf(AiReply("", listOf(call))))
        val out = Orchestrator(provider, FakeRunner(ToolResult.ok("x")), maxSteps = 3).respond("s", listOf(ChatMessage(Role.USER, "x")))
        assertEquals(3, provider.calls)
        assertTrue(out.last().text.contains("poora nahi"))
    }

    @Test fun trimHistoryNeverStartsWithOrphanTool() {
        val h = (1..40).flatMap { listOf(ChatMessage(Role.USER, "u$it"), ChatMessage(Role.TOOL, "t$it", toolCallId = "i")) }
        val t = Orchestrator.trimHistory(h, 31)
        assertEquals(Role.USER, t.first().role)
    }
}

class StorageTest {
    @get:Rule val tmp = TemporaryFolder()

    @Test fun conversationRoundTripAndSearch() {
        val store = ConversationStore(tmp.newFolder("c"))
        val call = ToolCall("c1", "open_app", JSONObject().put("name", "YouTube"))
        val msgs = listOf(ChatMessage(Role.USER, "YouTube kholo"), ChatMessage(Role.ASSISTANT, "", listOf(call), providerRaw = "{\"role\":\"model\"}"), ChatMessage(Role.TOOL, "OK: x", toolCallId = "c1", toolName = "open_app"))
        store.save(Conversation("id1", "YouTube kholo", 5L, msgs))
        val back = store.load("id1")!!
        assertEquals(3, back.messages.size)
        assertEquals("YouTube", back.messages[1].toolCalls[0].args.getString("name"))
        assertEquals("open_app", back.messages[2].toolName)
        assertEquals("{\"role\":\"model\"}", back.messages[1].providerRaw)
        assertEquals(1, store.search("youtube").size)
        assertEquals(0, store.search("zzz").size)
        store.delete("id1"); assertNull(store.load("id1"))
    }

    @Test fun itemStorePersistsAndClears() {
        val f = tmp.newFile("m.json")
        f.delete()
        val a = ItemStore(f); a.add("fact one", "fact"); a.add("fact two", "fact")
        val b = ItemStore(f)
        assertEquals(2, b.items.value.size)
        b.remove(b.items.value[0].id); assertEquals(1, ItemStore(f).items.value.size)
        b.clear(); assertTrue(ItemStore(f).items.value.isEmpty())
    }
}

class LiveParsersTest {
    @Test fun news() {
        val xml = """<rss><channel><item><title><![CDATA[Headline A &amp; B]]></title><link>https://x/1</link><pubDate>Mon, 01 Jan 2026</pubDate><source url="https://s">Src</source></item><item><title>H2</title><link>https://x/2</link></item></channel></rss>"""
        val items = NewsParser.parse(xml, 5)
        assertEquals(2, items.size)
        assertEquals("Headline A & B", items[0].title); assertEquals("Src", items[0].source)
    }
    @Test fun weather() {
        val j = """{"current":{"temperature_2m":31.5,"apparent_temperature":34.0,"relative_humidity_2m":40,"precipitation":0.0,"weather_code":2,"wind_speed_10m":9.0},
        "daily":{"time":["2026-01-01"],"weather_code":[61],"temperature_2m_max":[33.0],"temperature_2m_min":[20.0],"precipitation_probability_max":[70]}}"""
        val t = WeatherParser.parse(j, "Prayagraj, India")
        assertTrue(t.contains("Prayagraj")); assertTrue(t.contains("partly cloudy")); assertTrue(t.contains("light rain")); assertTrue(t.contains("70%"))
    }
}
