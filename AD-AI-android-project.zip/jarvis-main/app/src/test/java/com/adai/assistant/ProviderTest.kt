package com.adai.assistant

import com.adai.assistant.ai.GeminiProvider
import com.adai.assistant.ai.OpenAiCompatibleProvider
import com.adai.assistant.core.AiError
import com.adai.assistant.core.ChatMessage
import com.adai.assistant.core.NetworkException
import com.adai.assistant.core.Role
import com.adai.assistant.core.ToolCall
import com.adai.assistant.core.ToolParam
import com.adai.assistant.core.ToolSpec
import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** Provider tests run against a local fake HTTP server — no real API key or internet involved. */
class ProviderTest {
    private lateinit var server: MockWebServer
    private val tools = listOf(ToolSpec("open_app", "Open app", listOf(ToolParam("name", "string", "App", true))))
    private val user = listOf(ChatMessage(Role.USER, "YouTube kholo"))

    @Before fun up() { server = MockWebServer(); server.start() }
    @After fun down() { server.shutdown() }

    private fun base() = server.url("/v1").toString()

    @Test fun openAiParsesToolCallAndSendsBearer() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"role":"assistant","content":null,"tool_calls":[{"id":"call_9","type":"function","function":{"name":"open_app","arguments":"{\"name\":\"YouTube\"}"}}]}}]}"""))
        val r = OpenAiCompatibleProvider(base(), "sk-secret", "m").chat("sys", user, tools)
        assertEquals("open_app", r.toolCalls[0].name); assertEquals("YouTube", r.toolCalls[0].args.getString("name"))
        val req = server.takeRequest()
        assertEquals("Bearer sk-secret", req.getHeader("Authorization"))
        assertEquals("/v1/chat/completions", req.path)
        val body = JSONObject(req.body.readUtf8())
        assertEquals("function", body.getJSONArray("tools").getJSONObject(0).getString("type"))
    }

    @Test fun openAiPlainText() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"role":"assistant","content":"नमस्ते"}}]}"""))
        assertEquals("नमस्ते", OpenAiCompatibleProvider(base(), "k", "m").chat("s", user, emptyList()).text)
    }

    @Test fun openAiErrorMapping() = runBlocking {
        val cases = listOf(401 to AiError.InvalidKey::class.java, 402 to AiError.OutOfCredits::class.java, 429 to AiError.RateLimited::class.java, 404 to AiError.ModelNotFound::class.java)
        for ((code, cls) in cases) {
            server.enqueue(MockResponse().setResponseCode(code).setBody("""{"error":{"message":"x"}}"""))
            val e = try { OpenAiCompatibleProvider(base(), "k", "m").chat("s", user, emptyList()); null } catch (e: AiError) { e }
            assertEquals("code $code", cls, e?.javaClass)
        }
        server.enqueue(MockResponse().setResponseCode(429).setBody("""{"error":{"code":"insufficient_quota","message":"quota"}}"""))
        val q = try { OpenAiCompatibleProvider(base(), "k", "m").chat("s", user, emptyList()); null } catch (e: AiError) { e }
        assertEquals(AiError.OutOfCredits::class.java, q?.javaClass)
    }

    @Test fun errorMessagesNeverLeakKey() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(500).setBody("""{"error":{"message":"bad key sk-LEAKME"}}"""))
        val e = try { OpenAiCompatibleProvider(base(), "sk-LEAKME", "m").chat("s", user, emptyList()); null } catch (e: AiError) { e }
        assertFalse(e!!.message!!.contains("sk-LEAKME"))
    }

    @Test fun geminiParsesFunctionCallKeepsRawAndUsesHeaderKey() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"candidates":[{"content":{"role":"model","parts":[{"functionCall":{"name":"open_app","args":{"name":"YouTube"}},"thoughtSignature":"abc"}]}}]}"""))
        val p = GeminiProvider("gk", "gemini-x", server.url("/v1beta").toString())
        val r = p.chat("sys", user, tools)
        assertEquals("YouTube", r.toolCalls[0].args.getString("name"))
        assertTrue(r.providerRaw!!.contains("thoughtSignature"))
        val req = server.takeRequest()
        assertEquals("gk", req.getHeader("x-goog-api-key"))
        assertFalse(req.path!!.contains("gk"))
        assertTrue(req.path!!.endsWith("/models/gemini-x:generateContent"))
    }

    @Test fun geminiEchoesRawAndMergesToolResponses() {
        val p = GeminiProvider("k", "m")
        val raw = """{"role":"model","parts":[{"functionCall":{"name":"a","args":{}},"thoughtSignature":"sig"},{"functionCall":{"name":"b","args":{}}}]}"""
        val msgs = listOf(
            ChatMessage(Role.USER, "hi"),
            ChatMessage(Role.ASSISTANT, "", listOf(ToolCall("c0", "a", JSONObject()), ToolCall("c1", "b", JSONObject())), providerRaw = raw),
            ChatMessage(Role.TOOL, "OK: 1", toolCallId = "c0", toolName = "a"),
            ChatMessage(Role.TOOL, "OK: 2", toolCallId = "c1", toolName = "b"),
        )
        val contents = p.buildRequest("s", msgs, emptyList()).getJSONArray("contents")
        assertEquals(3, contents.length())
        assertTrue(contents.getJSONObject(1).toString().contains("sig"))
        assertEquals(2, contents.getJSONObject(2).getJSONArray("parts").length())
    }

    @Test fun geminiInvalidKeyAndBlocked() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(400).setBody("""{"error":{"message":"API key not valid. Please pass a valid API key.","status":"INVALID_ARGUMENT"}}"""))
        val e = try { GeminiProvider("k", "m", server.url("/v1beta").toString()).chat("s", user, emptyList()); null } catch (e: AiError) { e }
        assertEquals(AiError.InvalidKey::class.java, e?.javaClass)
        server.enqueue(MockResponse().setBody("""{"promptFeedback":{"blockReason":"SAFETY"}}"""))
        val b = try { GeminiProvider("k", "m", server.url("/v1beta").toString()).chat("s", user, emptyList()); null } catch (e: AiError) { e }
        assertEquals(AiError.Blocked::class.java, b?.javaClass)
    }

    @Test fun networkFailureIsReported() = runBlocking {
        val e = try { OpenAiCompatibleProvider("http://127.0.0.1:1/v1", "k", "m").chat("s", user, emptyList()); null } catch (e: NetworkException) { e }
        assertTrue(e != null)
    }
}
