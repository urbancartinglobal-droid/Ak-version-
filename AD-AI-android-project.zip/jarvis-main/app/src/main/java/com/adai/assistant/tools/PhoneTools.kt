package com.adai.assistant.tools

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.adai.assistant.core.ToolParam
import com.adai.assistant.core.ToolResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun ToolContext.launch(intent: Intent, okMsg: String): ToolResult = try {
    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    ToolResult.ok(okMsg)
} catch (e: ActivityNotFoundException) {
    ToolResult.fail("Is kaam ke liye phone par koi app nahi mili.")
}

object AppFinder {
    data class Entry(val label: String, val pkg: String)

    /** Pure matching logic (unit-tested): exact > startsWith > contains, case-insensitive. */
    fun pick(query: String, apps: List<Entry>): Entry? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        return apps.firstOrNull { it.label.lowercase() == q }
            ?: apps.firstOrNull { it.label.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.label.lowercase().contains(q) }
    }

    fun launchable(ctx: ToolContext): List<Entry> {
        val pm = ctx.context.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
    }
}

private data class Contact(val name: String, val number: String)

private suspend fun ToolContext.resolveContact(name: String): Pair<Contact?, String?> {
    val ok = ui.requestPermission(
        Manifest.permission.READ_CONTACTS,
        "Contact ka naam number se match karne ke liye aapke contacts padhne ki permission chahiye. Contacts sirf is phone par dekhe jaate hain; naam/number AI provider ko nahi bheje jaate.",
    )
    if (!ok) return null to "Contacts ki permission nahi mili. Aap number bata sakte hain."
    val found = mutableListOf<Contact>()
    withContext(Dispatchers.IO) { context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null,
    )?.use { c ->
        while (c.moveToNext() && found.size < 20) found += Contact(c.getString(0) ?: "", c.getString(1) ?: "")
    } }
    val distinct = found.distinctBy { it.name.lowercase() + it.number.filter { ch -> ch.isDigit() }.takeLast(10) }
    val byName = distinct.map { it.name }.distinct()
    return when {
        distinct.isEmpty() -> null to "'$name' naam ka koi contact nahi mila."
        byName.size > 1 -> null to "Kai contacts mile: ${byName.take(5).joinToString(", ")}. Kripya poora naam batayein."
        else -> distinct.first() to null
    }
}

fun phoneTools(): List<Tool> = listOf(

    tool("open_app", "Open an installed app by its name as shown on the phone (use Latin script, e.g. 'YouTube', 'WhatsApp', 'Camera').",
        listOf(ToolParam("name", "string", "App name", true))) { a, c ->
        val q = a.str("name")
        val app = AppFinder.pick(q, AppFinder.launchable(c))
            ?: return@tool ToolResult.fail("'$q' naam ka koi app phone mein nahi mila.")
        val intent = c.context.packageManager.getLaunchIntentForPackage(app.pkg)
            ?: return@tool ToolResult.fail("${app.label} ko open nahi kar sakte.")
        c.launch(intent, "${app.label} open karne ki request Android ko bhej di gayi.")
    },

    tool("open_camera", "Open the phone's camera app (does not take a photo).") { _, c ->
        c.launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Camera app khol diya gaya.")
    },

    tool("flashlight", "Turn the flashlight/torch on or off.",
        listOf(ToolParam("on", "boolean", "true to turn on, false to turn off", true))) { a, c ->
        if (!c.torch.available) return@tool ToolResult.fail("Is phone mein flashlight available nahi hai.")
        val on = a.optBoolean("on", true)
        if (c.torch.set(on)) ToolResult.ok("Torch ${if (on) "on" else "off"} ho gayi (Android ne confirm kiya).")
        else ToolResult.fail("Torch ${if (on) "on" else "off"} confirm nahi ho paayi. Shayad camera kisi aur app mein use ho raha hai.")
    },

    tool("battery_status", "Read the phone's battery level and charging state.") { _, c ->
        val i = c.context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return@tool ToolResult.fail("Battery ki jaankari nahi mil paayi.")
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "charging"
            BatteryManager.BATTERY_STATUS_FULL -> "full"
            BatteryManager.BATTERY_STATUS_DISCHARGING, BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "not charging"
            else -> "unknown"
        }
        val src = when (plug) { BatteryManager.BATTERY_PLUGGED_AC -> " (AC)"; BatteryManager.BATTERY_PLUGGED_USB -> " (USB)"; BatteryManager.BATTERY_PLUGGED_WIRELESS -> " (wireless)"; else -> "" }
        ToolResult.ok("Battery $pct%, $st$src.")
    },

    tool("network_status", "Report current connectivity (Wi-Fi / mobile data / none).") { _, c ->
        val cm = c.context.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        if (caps == null) return@tool ToolResult.ok("Koi active network nahi hai (offline).")
        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Other"
        }
        val net = if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "internet working" else "connected but internet not verified"
        ToolResult.ok("$type, $net, downlink approx ${caps.linkDownstreamBandwidthKbps / 1000} Mbps.")
    },

    tool("get_datetime", "Get the phone's current local date and time.") { _, _ ->
        ToolResult.ok(SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm:ss (zzzz)", Locale.ENGLISH).format(Date()))
    },

    tool("set_alarm", "Set an alarm at a clock time (24-hour). If the time already passed today, Android schedules it for the next occurrence (e.g. tomorrow).",
        listOf(
            ToolParam("hour", "integer", "Hour 0-23", true),
            ToolParam("minute", "integer", "Minute 0-59", true),
            ToolParam("label", "string", "Optional alarm label"),
        )) { a, c ->
        val h = a.optInt("hour", -1); val m = a.optInt("minute", -1)
        if (h !in 0..23 || m !in 0..59) return@tool ToolResult.fail("Time galat hai (hour 0-23, minute 0-59).")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.str("label").ifEmpty { "AD AI" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        c.launch(i, "Clock app ko %02d:%02d ka alarm set karne ki request bheji gayi. Android set hone ka confirmation nahi deta; Clock app mein ek baar check kar lein.".format(h, m))
    },

    tool("set_timer", "Start a countdown timer.",
        listOf(ToolParam("seconds", "integer", "Duration in seconds", true), ToolParam("label", "string", "Optional label"))) { a, c ->
        val s = a.optInt("seconds", -1)
        if (s !in 1..86400) return@tool ToolResult.fail("Timer 1 second se 24 ghante ke beech hona chahiye.")
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.str("label").ifEmpty { "AD AI" }).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        c.launch(i, "Clock app ko $s second ka timer start karne ki request bheji gayi (Clock app mein verify karein).")
    },

    tool("open_settings", "Open a system settings page.",
        listOf(ToolParam("page", "string", "Which page", true,
            listOf("main", "wifi", "bluetooth", "display", "sound", "battery_saver", "location", "airplane", "mobile_network", "nfc", "accessibility", "notification_access", "apps", "date_time", "language")))) { a, c ->
        val action = when (a.str("page")) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery_saver" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "mobile_network" -> Settings.ACTION_WIRELESS_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "notification_access" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "date_time" -> Settings.ACTION_DATE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        c.launch(Intent(action), "Settings page khol diya gaya. (Android apps ko Wi-Fi/Bluetooth khud toggle karne nahi deta; aap wahan se on/off kar sakte hain.)")
    },

    tool("open_dialer", "Open the phone dialer with a number pre-filled (does not place the call).",
        listOf(ToolParam("phone_number", "string", "Number to pre-fill", false))) { a, c ->
        val n = a.str("phone_number")
        c.launch(Intent(Intent.ACTION_DIAL, if (n.isEmpty()) null else Uri.parse("tel:" + Uri.encode(n))), "Dialer khul gaya.")
    },

    tool("open_contacts", "Open the Contacts app.") { _, c ->
        c.launch(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI), "Contacts app khul gaya.")
    },

    tool("call_contact", "Place a phone call to a saved contact or number. ALWAYS asks the user to confirm first.",
        listOf(ToolParam("contact_name", "string", "Saved contact name"), ToolParam("phone_number", "string", "Number, if no contact name"))) { a, c ->
        var display = a.str("phone_number"); var number = display
        if (a.str("contact_name").isNotEmpty()) {
            val (contact, err) = c.resolveContact(a.str("contact_name"))
            if (contact == null) return@tool ToolResult.fail(err ?: "Contact nahi mila.")
            display = contact.name; number = contact.number
        }
        if (number.isEmpty()) return@tool ToolResult.fail("Contact name ya phone number batayein.")
        if (!c.ui.confirm("Call karein?", "$display ($number) ko call lagayein?")) return@tool ToolResult.fail("User ne call cancel kar di.")
        val granted = c.ui.requestPermission(Manifest.permission.CALL_PHONE, "Seedha call lagane ke liye Phone permission chahiye. Warna main sirf dialer khol dunga.")
        if (granted) {
            c.launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))), "$display ko call lagane ki request Android ko bheji gayi.")
        } else {
            c.launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))), "Phone permission nahi hai, isliye $display ka number dialer mein bhar diya; call button aap dabayein.")
        }
    },

    tool("draft_sms", "Prepare an SMS draft and open the messaging app. It is NOT sent automatically: the user must press send there.",
        listOf(ToolParam("message", "string", "Message text", true), ToolParam("contact_name", "string", "Saved contact name"), ToolParam("phone_number", "string", "Number, if no contact name"))) { a, c ->
        var number = a.str("phone_number"); var who = number
        if (a.str("contact_name").isNotEmpty()) {
            val (contact, err) = c.resolveContact(a.str("contact_name"))
            if (contact == null) return@tool ToolResult.fail(err ?: "Contact nahi mila.")
            number = contact.number; who = contact.name
        }
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", a.str("message"))
        c.launch(i, "Messaging app mein ${if (who.isEmpty()) "naya" else who + " ke liye"} draft khul gaya. Message abhi BHEJA NAHI gaya; bhejne ke liye aap send dabayein.")
    },

    tool("open_maps", "Open Google Maps (or any maps app) to search a place or start navigation.",
        listOf(ToolParam("query", "string", "Place or address", true), ToolParam("navigate", "boolean", "true to start turn-by-turn navigation"))) { a, c ->
        val q = Uri.encode(a.str("query"))
        val uri = if (a.optBoolean("navigate", false)) Uri.parse("google.navigation:q=$q") else Uri.parse("geo:0,0?q=$q")
        c.launch(Intent(Intent.ACTION_VIEW, uri), "Maps mein '${a.str("query")}' khol diya gaya.")
    },

    tool("open_url", "Open a web page in the browser.", listOf(ToolParam("url", "string", "http(s) URL", true))) { a, c ->
        val u = a.str("url")
        if (!(u.startsWith("https://") || u.startsWith("http://"))) return@tool ToolResult.fail("Sirf http/https links khul sakte hain.")
        c.launch(Intent(Intent.ACTION_VIEW, Uri.parse(u)), "Link browser mein khol diya gaya.")
    },

    tool("web_search_in_browser", "Open a Google web search in the browser (no API key needed; results are viewed by the user, not read by the assistant).",
        listOf(ToolParam("query", "string", "Search query", true))) { a, c ->
        c.launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, a.str("query")), "Browser mein search khul gayi.")
    },

    tool("set_volume", "Change media volume.",
        listOf(ToolParam("action", "string", "What to do", true, listOf("up", "down", "set", "mute", "unmute")),
            ToolParam("percent", "integer", "Target percent 0-100 when action is 'set'"))) { a, c ->
        val am = c.context.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = when (a.str("action")) {
            "up" -> (am.getStreamVolume(AudioManager.STREAM_MUSIC) + maxOf(1, max / 7)).coerceAtMost(max)
            "down" -> (am.getStreamVolume(AudioManager.STREAM_MUSIC) - maxOf(1, max / 7)).coerceAtLeast(0)
            "set" -> (a.optInt("percent", -1).takeIf { it in 0..100 } ?: return@tool ToolResult.fail("percent 0-100 batayein.")) * max / 100
            "mute" -> 0
            "unmute" -> maxOf(1, max / 2)
            else -> return@tool ToolResult.fail("Unknown volume action.")
        }
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        val now = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (now == target) ToolResult.ok("Media volume ab ${now * 100 / max}% hai (verified).")
        else ToolResult.fail("Volume badalne ki koshish ki, par abhi ${now * 100 / max}% hai.")
    },

    tool("share_text", "Open Android's share sheet with some text.", listOf(ToolParam("text", "string", "Text to share", true))) { a, c ->
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.str("text"))
        c.launch(Intent.createChooser(send, "Share"), "Share sheet khul gayi; aap app chunkar bhejein.")
    },
)
