@file:OptIn(ExperimentalMaterial3Api::class)

package com.adai.assistant.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.VisualTransformation
import com.adai.assistant.ai.ProviderFactory
import com.adai.assistant.settings.AppSettings

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit, singleLine: Boolean = true) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (id, label) -> FilterChip(selected = selected == id, onClick = { onSelect(id) }, label = { Text(label) }) }
    }
}

@Composable
private fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Write-only secret field: the saved key is never shown again, only replaced or deleted. */
@Composable
private fun SecretField(label: String, saved: Boolean, onSave: (String) -> Unit, onDelete: () -> Unit) {
    var input by remember { mutableStateOf("") }
    OutlinedTextField(
        value = input, onValueChange = { input = it }, label = { Text(label) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
        supportingText = { Text(if (saved) "✓ Key saved (encrypted on this phone). Naya daalkar Save karein to replace hogi." else "Abhi koi key saved nahi hai.") },
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onSave(input.trim()); input = "" }, enabled = input.isNotBlank()) { Text("Save") }
        OutlinedButton(onClick = onDelete, enabled = saved) { Text("Delete key") }
    }
}

@Composable
private fun ConfirmAction(title: String, text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(text) },
        confirmButton = { Button(onClick = { onConfirm(); onDismiss() }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s by vm.settings.state.collectAsState()
    val test by vm.testStatus.collectAsState()
    val memory by vm.memory.items.collectAsState()
    val cmds by vm.commands.items.collectAsState()
    val store = vm.settings
    fun upd(t: (AppSettings) -> AppSettings) = store.update(t)

    var showVoices by remember { mutableStateOf(false) }
    var showAddCmd by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<String?>(null) }
    var newFact by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)

        Section("AI Brain") {
            Chips(listOf(ProviderFactory.GEMINI to "Google Gemini", ProviderFactory.OPENAI_COMPAT to "OpenAI-compatible"), s.provider) { p ->
                upd { it.copy(provider = p, model = if (p == ProviderFactory.GEMINI) "gemini-2.5-flash" else "gpt-4o-mini", baseUrl = if (p == ProviderFactory.GEMINI) it.baseUrl else "https://api.openai.com/v1") }
            }
            if (s.provider == ProviderFactory.OPENAI_COMPAT) {
                Text("Presets:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { upd { it.copy(baseUrl = "https://api.openai.com/v1", model = "gpt-4o-mini") } }) { Text("OpenAI") }
                    TextButton(onClick = { upd { it.copy(baseUrl = "https://api.groq.com/openai/v1", model = "llama-3.3-70b-versatile") } }) { Text("Groq") }
                    TextButton(onClick = { upd { it.copy(baseUrl = "https://openrouter.ai/api/v1", model = "openai/gpt-4o-mini") } }) { Text("OpenRouter") }
                }
                Field("Base URL (https)", s.baseUrl, { v -> upd { it.copy(baseUrl = v.trim()) } })
            }
            Field("Model name", s.model, { v -> upd { it.copy(model = v.trim()) } })
            Text("Model names badalte rehte hain — provider ki docs se current naam check karein.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SecretField("API key", s.apiKey.isNotEmpty(), { k -> upd { it.copy(apiKey = k) } }, { upd { it.copy(apiKey = "") } })
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.testConnection() }) { Text("Test connection") }
            }
            if (test.isNotEmpty()) Text(test, style = MaterialTheme.typography.bodySmall)
        }

        Section("Assistant & Voice") {
            Field("Assistant ka naam", s.assistantName, { v -> upd { it.copy(assistantName = v) } })
            Text("Personality", style = MaterialTheme.typography.labelMedium)
            Chips(listOf("jarvis" to "Jarvis", "friendly" to "Friendly", "custom" to "Custom"), s.personality) { p -> upd { it.copy(personality = p) } }
            if (s.personality == "custom") Field("Custom personality instructions", s.customPersonality, { v -> upd { it.copy(customPersonality = v) } }, singleLine = false)
            Text("Bolne ki bhasha (speech recognition)", style = MaterialTheme.typography.labelMedium)
            Chips(listOf("hi-IN" to "Hindi", "en-IN" to "English (India)", "en-US" to "English (US)"), s.recognitionLang) { l -> upd { it.copy(recognitionLang = l) } }
            Text("Jawab bolne ki bhasha", style = MaterialTheme.typography.labelMedium)
            Chips(listOf("auto" to "Auto", "hi-IN" to "Hindi", "en-IN" to "English (IN)", "en-US" to "English (US)"), s.speakLang) { l -> upd { it.copy(speakLang = l) } }
            Toggle("Jawab bolkar sunayein", s.speakReplies) { v -> upd { it.copy(speakReplies = v) } }
            Text("Speed: ${"%.1f".format(s.ttsRate)}x", style = MaterialTheme.typography.labelMedium)
            Slider(value = s.ttsRate, onValueChange = { v -> upd { it.copy(ttsRate = v) } }, valueRange = 0.5f..2f)
            Text("Pitch: ${"%.1f".format(s.ttsPitch)}", style = MaterialTheme.typography.labelMedium)
            Slider(value = s.ttsPitch, onValueChange = { v -> upd { it.copy(ttsPitch = v) } }, valueRange = 0.5f..2f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showVoices = true }) { Text("Choose voice") }
                Button(onClick = { vm.testVoice() }) { Text("Test voice") }
            }
            if (s.ttsVoice.isNotEmpty()) Text("Voice: ${s.ttsVoice}", style = MaterialTheme.typography.bodySmall)
        }

        Section("Live data") {
            Field("Home city (weather default, Latin script)", s.homeCity, { v -> upd { it.copy(homeCity = v) } })
            Text("Bina key ke chalne wale: Weather (Open-Meteo), News (Google News RSS), Currency (ECB via Frankfurter), Wikipedia.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Web search (scores, prices, sarkari info) ke liye Tavily API key chahiye:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SecretField("Tavily API key", s.tavilyKey.isNotEmpty(), { k -> upd { it.copy(tavilyKey = k) } }, { upd { it.copy(tavilyKey = "") } })
        }

        Section("Memory") {
            Toggle("Memory on (AI ko yaad rakhne dein)", s.memoryEnabled) { v -> upd { it.copy(memoryEnabled = v) } }
            memory.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("• ${m.text}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    IconButton(onClick = { vm.memory.remove(m.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Forget") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(newFact, { newFact = it }, Modifier.weight(1f), placeholder = { Text("Kuch yaad rakhwayein…") }, singleLine = true)
                Button(onClick = { vm.memory.add(newFact, "fact"); newFact = "" }, enabled = newFact.isNotBlank()) { Text("Add") }
            }
            if (memory.isNotEmpty()) TextButton(onClick = { pendingDelete = "memory" }) { Text("Saari memory delete karein") }
        }

        Section("Custom commands") {
            Text("Apna phrase set karein jo bina AI/internet ke chale (app kholna, link kholna, ya fixed jawab).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            cmds.forEach { c ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("“${c.text}” → ${c.kind}: ${c.extra}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    IconButton(onClick = { vm.commands.remove(c.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete command") }
                }
            }
            Button(onClick = { showAddCmd = true }) { Text("Add command") }
            Text("Routines (multi-step automation) aur wake word: planned — abhi implemented nahi (FEATURES_STATUS.md dekhein).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Section("Privacy") {
            Toggle("Conversation history phone par save karein", s.saveHistory) { v -> upd { it.copy(saveHistory = v) } }
            Toggle("Offline quick commands (torch, battery, app kholo)", s.offlineCommands) { v -> upd { it.copy(offlineCommands = v) } }
            Text("Kya kahan jaata hai: aapki baat AI provider (Gemini/OpenAI-compatible) ko bheji jaati hai. Weather/news/currency/Wikipedia ko sirf query (jaise shehar ka naam). Voice recognition Android ki Google speech service karti hai. History, memory, notes aur keys sirf is phone par rehte hain (keys encrypted).",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { pendingDelete = "history" }) { Text("Saari conversations delete karein") }
            OutlinedButton(onClick = { pendingDelete = "notes" }) { Text("Saved notes delete karein") }
            OutlinedButton(onClick = { pendingDelete = "keys" }) { Text("Saari API keys delete karein") }
        }
        Spacer(Modifier.padding(8.dp))
    }

    if (showVoices) {
        val voices = remember(showVoices) { vm.voices() }
        AlertDialog(
            onDismissRequest = { showVoices = false }, title = { Text("Voice chunein") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    TextButton(onClick = { upd { it.copy(ttsVoice = "") }; showVoices = false }) { Text("Default") }
                    if (voices.isEmpty()) Text("Is bhasha ke liye koi voice nahi mili. Phone Settings → Text-to-speech se voice data install karein.")
                    voices.forEach { v -> TextButton(onClick = { upd { it.copy(ttsVoice = v.name) }; showVoices = false }) { Text(v.name) } }
                }
            },
            confirmButton = { TextButton(onClick = { showVoices = false }) { Text("Close") } },
        )
    }

    if (showAddCmd) {
        var trigger by remember { mutableStateOf("") }
        var kind by remember { mutableStateOf("open_app") }
        var value by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddCmd = false }, title = { Text("New command") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field("Jab main kahun (phrase)", trigger, { trigger = it })
                    Chips(listOf("open_app" to "App kholo", "open_url" to "Link kholo", "say" to "Bolo", "routine" to "Routine"), kind) { kind = it }
                    Field(when (kind) { "open_app" -> "App ka naam"; "open_url" -> "https://…"; "routine" -> "open_app:YouTube; flashlight:on; volume:up"; else -> "Jawab" }, value, { value = it })
                }
            },
            confirmButton = { Button(onClick = { vm.commands.add(trigger.lowercase().trim(), kind, value.trim()); showAddCmd = false }, enabled = trigger.isNotBlank() && value.isNotBlank()) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showAddCmd = false }) { Text("Cancel") } },
        )
    }

    pendingDelete?.let { what ->
        ConfirmAction(
            title = "Pakka delete karein?", text = "Yeh wapas nahi aayega.",
            onConfirm = {
                when (what) {
                    "memory" -> vm.memory.clear()
                    "notes" -> vm.notes.clear()
                    "history" -> vm.deleteAllConversations()
                    "keys" -> store.deleteSecrets()
                }
            },
            onDismiss = { pendingDelete = null },
        )
    }
}
