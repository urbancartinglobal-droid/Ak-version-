package com.adai.assistant

import android.app.Application
import com.adai.assistant.data.ConversationStore
import com.adai.assistant.data.ItemStore
import com.adai.assistant.live.LiveData
import com.adai.assistant.settings.SettingsStore
import com.adai.assistant.tools.TorchController
import java.io.File

/** Simple manual dependency container (no DI framework to keep builds light). */
class AppContainer(app: Application) {
    val settings = SettingsStore(app)
    val conversations = ConversationStore(File(app.filesDir, "conversations"))
    val memory = ItemStore(File(app.filesDir, "memory.json"))
    val notes = ItemStore(File(app.filesDir, "notes.json"))
    val commands = ItemStore(File(app.filesDir, "custom_commands.json"))
    val live = LiveData { settings.current }
    val torch = TorchController(app)
}

class AdAiApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
