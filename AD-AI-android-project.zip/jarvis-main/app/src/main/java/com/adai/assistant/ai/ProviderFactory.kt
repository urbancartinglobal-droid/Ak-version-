package com.adai.assistant.ai

import com.adai.assistant.core.AiError
import com.adai.assistant.settings.AppSettings

/** Single place that turns settings into a provider. Register new providers here. */
object ProviderFactory {
    const val GEMINI = "gemini"
    const val OPENAI_COMPAT = "openai_compat"

    fun create(s: AppSettings): AiProvider {
        if (s.apiKey.isBlank()) throw AiError.MissingKey()
        return when (s.provider) {
            OPENAI_COMPAT -> OpenAiCompatibleProvider(s.baseUrl, s.apiKey, s.model)
            else -> GeminiProvider(s.apiKey, s.model)
        }
    }
}
