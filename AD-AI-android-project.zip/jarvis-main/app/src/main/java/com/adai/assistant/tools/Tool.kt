package com.adai.assistant.tools

import android.content.Context
import com.adai.assistant.core.NetworkException
import com.adai.assistant.core.ToolCall
import com.adai.assistant.core.ToolParam
import com.adai.assistant.core.ToolResult
import com.adai.assistant.core.ToolRunner
import com.adai.assistant.core.ToolSpec
import com.adai.assistant.data.ItemStore
import com.adai.assistant.live.LiveData
import com.adai.assistant.settings.AppSettings
import org.json.JSONObject
import kotlin.coroutines.cancellation.CancellationException

/** What tools need from the UI layer: user confirmation and runtime-permission prompts. */
interface UiBridge {
    suspend fun confirm(title: String, detail: String): Boolean
    /** Explains why, asks the system for [permission], returns whether it is now granted. */
    suspend fun requestPermission(permission: String, rationale: String): Boolean
}

class ToolContext(
    val context: Context,
    val settings: () -> AppSettings,
    val ui: UiBridge,
    val live: LiveData,
    val notes: ItemStore,
    val memory: ItemStore,
    val torch: TorchController,
)

interface Tool {
    val spec: ToolSpec
    suspend fun run(args: JSONObject, ctx: ToolContext): ToolResult
}

fun tool(
    name: String,
    description: String,
    params: List<ToolParam> = emptyList(),
    block: suspend (JSONObject, ToolContext) -> ToolResult,
): Tool = object : Tool {
    override val spec = ToolSpec(name, description, params)
    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolResult = block(args, ctx)
}

/** Validates arguments, then executes the named tool. All failures become [ToolResult.fail], never crashes. */
class ToolRegistry(private val ctx: ToolContext, tools: List<Tool>) : ToolRunner {
    private val map = tools.associateBy { it.spec.name }
    override val specs: List<ToolSpec> = tools.map { it.spec }

    override suspend fun execute(call: ToolCall): ToolResult {
        val t = map[call.name] ?: return ToolResult.fail("Unknown tool '${call.name}'")
        for (p in t.spec.params) {
            if (p.required && (!call.args.has(p.name) || call.args.isNull(p.name))) {
                return ToolResult.fail("Missing required argument '${p.name}'")
            }
        }
        return try {
            t.run(call.args, ctx)
        } catch (e: CancellationException) {
            throw e
        } catch (e: NetworkException) {
            ToolResult.fail(e.message ?: "Network error")
        } catch (e: SecurityException) {
            ToolResult.fail("Android ne permission nahi di (${call.name}).")
        } catch (e: Exception) {
            ToolResult.fail("${call.name} failed (${e.javaClass.simpleName}).")
        }
    }
}

fun JSONObject.str(name: String): String = if (has(name) && !isNull(name)) optString(name, "").trim() else ""
fun JSONObject.hasVal(name: String): Boolean = has(name) && !isNull(name)
