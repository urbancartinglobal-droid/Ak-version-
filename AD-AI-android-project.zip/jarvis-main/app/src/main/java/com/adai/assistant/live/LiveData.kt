package com.adai.assistant.live

import com.adai.assistant.ai.Http
import com.adai.assistant.core.NetworkException
import com.adai.assistant.settings.AppSettings
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Result of a live-data lookup. Always carries when it was fetched and where it came from. */
data class LiveResult(val body: String, val sources: List<String>, val fetchedAt: Long, val cached: Boolean = false) {
    fun toModelText(): String {
        val f = SimpleDateFormat("d MMM yyyy HH:mm", Locale.ENGLISH).format(Date(fetchedAt))
        val ageMin = ((System.currentTimeMillis() - fetchedAt) / 60000).toInt()
        val fresh = if (cached) "CACHED data fetched $ageMin min ago at $f (not re-fetched)" else "LIVE data fetched at $f"
        val src = if (sources.isEmpty()) "" else "\nSources: " + sources.joinToString(", ")
        return "$fresh\n$body$src"
    }
}

private class TtlCache {
    private val map = HashMap<String, LiveResult>()
    @Synchronized fun get(key: String, ttlMs: Long): LiveResult? =
        map[key]?.takeIf { System.currentTimeMillis() - it.fetchedAt < ttlMs }?.copy(cached = true)
    @Synchronized fun put(key: String, v: LiveResult) { map[key] = v }
}

/**
 * Modular live-data facade. Each method is an independent provider; to add a new one, add a method
 * (and a Tool in LiveTools.kt). Nothing here ever fabricates data: on any failure it throws [NetworkException].
 */
class LiveData(private val settings: () -> AppSettings) {
    private val cache = TtlCache()
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun f4(v: Double) = String.format(Locale.US, "%.4f", v)

    private suspend fun getOk(url: String): String {
        val r = Http.get(url)
        if (r.code !in 200..299) throw NetworkException("Service ne error diya (HTTP ${r.code}).")
        return r.body
    }

    // ---- Weather (Open-Meteo: no API key) ----
    suspend fun weather(city: String): LiveResult {
        val key = "w:" + city.lowercase()
        cache.get(key, 10 * 60_000L)?.let { return it }
        val geo = JSONObject(getOk("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1&language=en&format=json"))
        val hit = geo.optJSONArray("results")?.optJSONObject(0) ?: throw NetworkException("'$city' naam ki jagah nahi mili.")
        val place = hit.optString("name") + ", " + hit.optString("country")
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${hit.getDouble("latitude")}&longitude=${hit.getDouble("longitude")}" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3"
        val res = LiveResult(WeatherParser.parse(getOk(url), place), listOf("https://open-meteo.com"), System.currentTimeMillis())
        cache.put(key, res)
        return res
    }

    // ---- News (Google News RSS: no key) ----
    suspend fun news(query: String?, hindi: Boolean): LiveResult {
        val key = "n:${query.orEmpty().lowercase()}:$hindi"
        cache.get(key, 5 * 60_000L)?.let { return it }
        val loc = if (hindi) "hl=hi&gl=IN&ceid=IN:hi" else "hl=en-IN&gl=IN&ceid=IN:en"
        val url = if (query.isNullOrBlank()) "https://news.google.com/rss?$loc" else "https://news.google.com/rss/search?q=${enc(query)}&$loc"
        val items = NewsParser.parse(getOk(url), 6)
        if (items.isEmpty()) throw NetworkException("Is topic par abhi koi khabar nahi mili.")
        val body = items.joinToString("\n") { "- ${it.title} (${it.source}, ${it.published}) ${it.link}" }
        val res = LiveResult(body, listOf("Google News RSS"), System.currentTimeMillis())
        cache.put(key, res)
        return res
    }

    // ---- Currency (Frankfurter / ECB reference rates: no key; limited currency list) ----
    suspend fun exchange(from: String, to: String, amount: Double): LiveResult {
        val f = from.uppercase().trim(); val t = to.uppercase().trim()
        val key = "fx:$f:$t"
        val rate: Double; val date: String
        val c = cache.get(key, 30 * 60_000L)
        if (c != null) {
            return c.copy(body = "$amount $f = ${f4(amount * c.body.substringBefore('|').toDouble())} $t (rate ${c.body.substringBefore('|')}, ECB date ${c.body.substringAfter('|')})")
        }
        val json = JSONObject(getOk("https://api.frankfurter.dev/v1/latest?base=$f&symbols=$t"))
        rate = json.optJSONObject("rates")?.optDouble(t, Double.NaN) ?: Double.NaN
        if (rate.isNaN()) throw NetworkException("$f → $t rate is source par available nahi hai.")
        date = json.optString("date")
        cache.put(key, LiveResult("$rate|$date", listOf("https://frankfurter.dev (ECB)"), System.currentTimeMillis()))
        return LiveResult(
            "$amount $f = ${f4(amount * rate)} $t (rate $rate, ECB reference date $date; indicative, not a bank rate)",
            listOf("https://frankfurter.dev (ECB)"), System.currentTimeMillis(),
        )
    }

    // ---- Wikipedia (general knowledge, no key) ----
    suspend fun wikipedia(query: String, hindi: Boolean): LiveResult {
        val lang = if (hindi) "hi" else "en"
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${enc(query)}&gsrlimit=1" +
            "&prop=extracts&exintro=1&explaintext=1&exsentences=5&redirects=1&format=json"
        val pages = JSONObject(getOk(url)).optJSONObject("query")?.optJSONObject("pages")
        val page = pages?.keys()?.asSequence()?.firstOrNull()?.let { pages.getJSONObject(it) }
            ?: throw NetworkException("Wikipedia par '$query' nahi mila.")
        val title = page.optString("title")
        return LiveResult(
            "$title: ${page.optString("extract").trim()}",
            listOf("https://$lang.wikipedia.org/wiki/${enc(title.replace(' ', '_'))}"),
            System.currentTimeMillis(),
        )
    }

    // ---- Web search (Tavily: requires the user's own API key) ----
    suspend fun search(query: String): LiveResult {
        val key = settings().tavilyKey
        if (key.isBlank()) throw NetworkException("Web search ke liye Settings → Live Data mein Tavily API key daalni hogi.")
        val body = JSONObject().put("query", query).put("max_results", 5).put("include_answer", true)
        val r = Http.postJson("https://api.tavily.com/search", body, mapOf("Authorization" to "Bearer $key"))
        if (r.code == 401 || r.code == 403) throw NetworkException("Tavily API key galat hai.")
        if (r.code == 429 || r.code == 432 || r.code == 433) throw NetworkException("Tavily ki limit/quota poori ho gayi hai.")
        if (r.code !in 200..299) throw NetworkException("Search service error (HTTP ${r.code}).")
        val j = JSONObject(r.body)
        val results = j.optJSONArray("results")
        val sb = StringBuilder()
        j.optString("answer").takeIf { it.isNotBlank() }?.let { sb.append("Summary: ").append(it).append('\n') }
        val srcs = mutableListOf<String>()
        if (results != null) for (i in 0 until results.length()) {
            val o = results.getJSONObject(i)
            sb.append("- ${o.optString("title")}: ${o.optString("content").take(300)}\n")
            srcs += o.optString("url")
        }
        if (srcs.isEmpty() && sb.isEmpty()) throw NetworkException("Koi search result nahi mila.")
        return LiveResult(sb.toString().trim(), srcs, System.currentTimeMillis())
    }
}

object WeatherParser {
    private fun code(c: Int) = when (c) {
        0 -> "clear sky"; 1 -> "mainly clear"; 2 -> "partly cloudy"; 3 -> "overcast"
        45, 48 -> "fog"; 51, 53, 55 -> "drizzle"; 56, 57 -> "freezing drizzle"
        61 -> "light rain"; 63 -> "rain"; 65 -> "heavy rain"; 66, 67 -> "freezing rain"
        71, 73, 75, 77 -> "snow"; 80, 81, 82 -> "rain showers"; 85, 86 -> "snow showers"
        95 -> "thunderstorm"; 96, 99 -> "thunderstorm with hail"; else -> "unknown (code $c)"
    }

    fun parse(json: String, place: String): String {
        val j = JSONObject(json)
        val c = j.getJSONObject("current")
        val sb = StringBuilder("Weather for $place: now ${c.optDouble("temperature_2m")}°C (feels ${c.optDouble("apparent_temperature")}°C), " +
            "${code(c.optInt("weather_code", -1))}, humidity ${c.optInt("relative_humidity_2m")}%, wind ${c.optDouble("wind_speed_10m")} km/h, precipitation ${c.optDouble("precipitation")} mm.")
        val d = j.optJSONObject("daily")
        if (d != null) {
            val days = d.getJSONArray("time")
            for (i in 0 until days.length()) {
                sb.append("\n${days.getString(i)}: ${code(d.getJSONArray("weather_code").optInt(i, -1))}, " +
                    "${d.getJSONArray("temperature_2m_min").optDouble(i)}–${d.getJSONArray("temperature_2m_max").optDouble(i)}°C, " +
                    "rain chance up to ${d.getJSONArray("precipitation_probability_max").optInt(i)}%")
            }
        }
        return sb.toString()
    }
}

data class NewsItem(val title: String, val link: String, val source: String, val published: String)

object NewsParser {
    private fun decode(s: String) = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").trim()

    private fun tag(block: String, name: String): String =
        Regex("<$name[^>]*>(.*?)</$name>", RegexOption.DOT_MATCHES_ALL).find(block)?.groupValues?.get(1)?.let { decode(it) }.orEmpty()

    fun parse(xml: String, max: Int): List<NewsItem> =
        Regex("<item>(.*?)</item>", RegexOption.DOT_MATCHES_ALL).findAll(xml).take(max).map {
            val b = it.groupValues[1]
            NewsItem(tag(b, "title"), tag(b, "link"), tag(b, "source"), tag(b, "pubDate"))
        }.filter { it.title.isNotEmpty() }.toList()
}
