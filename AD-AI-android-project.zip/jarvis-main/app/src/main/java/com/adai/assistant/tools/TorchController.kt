package com.adai.assistant.tools

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.delay

/** Flashlight control with verification: success is reported only after Android's TorchCallback confirms the state. */
class TorchController(context: Context) {
    private val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val cameraId: String? = try {
        cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    } catch (e: Exception) { null }

    @Volatile private var state: Boolean? = null

    init {
        if (cameraId != null) {
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(id: String, enabled: Boolean) { if (id == cameraId) state = enabled }
                override fun onTorchModeUnavailable(id: String) { if (id == cameraId) state = null }
            }, Handler(Looper.getMainLooper()))
        }
    }

    val available: Boolean get() = cameraId != null

    /** Returns true only if the torch is confirmed to be in the requested state. */
    suspend fun set(on: Boolean): Boolean {
        val id = cameraId ?: return false
        cm.setTorchMode(id, on)
        repeat(10) {
            if (state == on) return true
            delay(60)
        }
        return state == on
    }
}
