package com.adai.assistant.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.speech.tts.Voice
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.adai.assistant.AdAiApp
import com.adai.assistant.ai.ProviderFactory
import com.adai.assistant.core.AiError
import com.adai.assistant.core.ChatMessage
import com.adai.assistant.core.NetworkException
import com.adai.assistant.core.Orchestrator
import com.adai.assistant.core.Prompts
import com.adai.assistant.core.Role
import com.adai.assistant.core.ToolCall
import com.adai.assistant.data.Conversation
import com.adai.assistant.tools.OfflineRouter
import com.adai.assistant.tools.ToolContext
import com.adai.assistant.tools.ToolRegistry
import com.adai.assistant.tools.UiBridge
import com.adai.assistant.tools.liveTools
import com.adai.assistant.tools.miscTools
import com.adai.assistant.tools.phoneTools
import com.adai.assistant.voice.SpeechInput
import com.adai.assistant.voice.SpeechOutput
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.resume

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

data class ConfirmRequest(val title: String, val detail: String, val deferred: CompletableDeferred<Boolean>)

data class UiState(
    val conversationId: String,
    val messages: List<ChatMessage> = emptyList(),
    val phase: Phase = Phase.IDLE,
    val partial: String = "",
    val status: String = "",
    val error: String? = null,
    val confirm: ConfirmRequest? = null,
    val handsFree: Boolean = false,
)

class AppViewModel(app: Application) : AndroidViewModel(app), UiBridge {
    private val container = (app as AdAiApp).container
    val settings = container.settings
    val memory = container.memory
    val notes = container.notes
    val commands = container.commands

    private val speechIn = SpeechInput(app)
    private val speechOut = SpeechOutput(app)
    private val registry = ToolRegistry(
        ToolContext(app, { settings.current }, this, container.live, container.notes, container.memory, container.torch),
        phoneTools() + liveTools() + miscTools(),
    )

    private val _ui = MutableStateFlow(UiState(conversationId = container.conversations.newId()))
    val ui: StateFlow<UiState> = _ui
    val level = MutableStateFlow(0f)
    val testStatus = MutableStateFlow("")
    val history = MutableStateFlow<List<Conversation>>(emptyList())

    /** Set by MainActivity: launches the system permission dialog and reports the result. */
    var permissionLauncher: ((String, (Boolean) -> Unit) -> Unit)? = null

    private var job: Job? = null
    private var failStreak = 0

    // ------------------------------------------------------------------ UiBridge
    override suspend fun confirm(title: String, detail: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        _ui.update { it.copy(confirm = ConfirmRequest(title, detail, d)) }
        return try { d.await() } finally { _ui.update { it.copy(confirm = null) } }
    }

    fun answerConfirm(ok: Boolean) { _ui.value.confirm?.deferred?.complete(ok) }

    override suspend fun requestPermission(permission: String, rationale: String): Boolean {
        val app = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(app, permission) == PackageManager.PERMISSION_GRANTED) return true
        if (!confirm("Permission chahiye", rationale)) return false
        val launcher = permissionLauncher ?: return false
        return suspendCancellableCoroutine { cont -> launcher(permission) { granted -> if (cont.isActive) cont.resume(granted) } }
    }

    // ------------------------------------------------------------------ Voice flow
    fun onMicClick() {
        when (_ui.value.phase) {
            Phase.SPEAKING -> { speechOut.stop(); startListening() }           // interrupt and talk
            Phase.LISTENING -> speechIn.stop()                                  // finish utterance now
            Phase.THINKING -> { job?.cancel(); setPhase(Phase.IDLE) }          // cancel
            Phase.IDLE -> startListening()
        }
    }

    fun stopSpeaking() {
        speechOut.stop()
        if (_ui.value.phase == Phase.SPEAKING) setPhase(Phase.IDLE)
    }

    fun toggleHandsFree() {
        val on = !_ui.value.handsFree
        _ui.update { it.copy(handsFree = on) }
        failStreak = 0
        if (on && _ui.value.phase == Phase.IDLE) startListening()
        if (!on && _ui.value.phase == Phase.LISTENING) { speechIn.cancel(); setPhase(Phase.IDLE) }
    }

    private fun startListening() {
        viewModelScope.launch {
            val granted = requestPermission(
                Manifest.permission.RECORD_AUDIO,
                "Aapki awaaz sunne ke liye microphone permission chahiye. Mic sirf tab chalta hai jab aap mic dabate hain (ya hands-free on ho aur app khula ho). Speech recognition Android ki Google speech service se hota hai, jo audio ko online process kar sakti hai.",
            )
            if (!granted) { fail("Microphone permission ke bina voice input nahi chal sakta."); disableHandsFree(); return@launch }
            if (!speechIn.available) { fail("Is phone par speech recognition service nahi mili. Google app / Speech Services install karein."); disableHandsFree(); return@launch }
            _ui.update { it.copy(phase = Phase.LISTENING, partial = "", error = null, status = "") }
            speechIn.start(
                language = settings.current.recognitionLang,
                onPartial = { p -> _ui.update { it.copy(partial = p) } },
                onResult = { r -> failStreak = 0; level.value = 0f; sendText(r) },
                onFail = { msg, silent -> onListenFail(msg, silent) },
                onLevel = { l -> level.value = l },
            )
        }
    }

    private fun onListenFail(msg: String, silent: Boolean) {
        level.value = 0f
        _ui.update { it.copy(phase = Phase.IDLE, partial = "", error = if (silent) null else msg, status = if (silent) msg else "") }
        if (_ui.value.handsFree) {
            failStreak++
            if (silent && failStreak < 3) startListening()
            else { failStreak = 0; disableHandsFree(); if (silent) _ui.update { it.copy(status = "Hands-free band: kuch sunai nahi diya.") } }
        }
    }

    private fun disableHandsFree() { _ui.update { it.copy(handsFree = false) } }

    // ------------------------------------------------------------------ Conversation
    fun sendText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        speechOut.stop(); speechIn.cancel()
        job?.cancel()
        _ui.update { it.copy(messages = it.messages + ChatMessage(Role.USER, t), phase = Phase.THINKING, partial = "", error = null, status = "") }
        job = viewModelScope.launch {
            val reply = try {
                produceReply(t)
            } catch (e: CancellationException) {
                throw e
            } catch (e: AiError) {
                fail(e.message); return@launch
            } catch (e: NetworkException) {
                fail(e.message); return@launch
            } catch (e: Exception) {
                fail("Kuch galat ho gaya (${e.javaClass.simpleName})."); return@launch
            }
            _ui.update { it.copy(messages = it.messages + reply) }
            persist()
            deliver(reply.lastOrNull { it.role == Role.ASSISTANT && it.text.isNotBlank() }?.text)
        }
    }

    private suspend fun produceReply(input: String): List<ChatMessage> {
        val s = settings.current
        val norm = input.lowercase().trim().trimEnd('.', '!', '?')

        // 1) User-defined custom commands (work offline).
        val cmd = commands.items.value.firstOrNull { c -> val tr = c.text.lowercase().trim(); tr.isNotEmpty() && (norm == tr || norm.contains(tr)) }
        if (cmd != null) {
            if (cmd.kind == "say") return listOf(ChatMessage(Role.ASSISTANT, cmd.extra))
            if (cmd.kind == "routine") return listOf(ChatMessage(Role.ASSISTANT, runRoutine(cmd.extra)))
            val tool = if (cmd.kind == "open_url") "open_url" else "open_app"
            val args = JSONObject().put(if (cmd.kind == "open_url") "url" else "name", cmd.extra)
            return listOf(ChatMessage(Role.ASSISTANT, registry.execute(ToolCall("custom", tool, args)).message))
        }
        // 2) Offline fast-path for a few unambiguous device commands.
        if (s.offlineCommands) {
            OfflineRouter.route(input)?.let { a ->
                return listOf(ChatMessage(Role.ASSISTANT, registry.execute(ToolCall("offline", a.tool, a.args)).message))
            }
        }
        // 3) Full AI + tools loop (throws AiError.MissingKey if no key is configured).
        val provider = ProviderFactory.create(s)
        val facts = if (s.memoryEnabled) memory.items.value.map { it.text } else emptyList()
        return Orchestrator(provider, registry).respond(Prompts.system(s, facts), _ui.value.messages) { st ->
            _ui.update { it.copy(status = st) }
        }
    }

    /** Routine format: "open_app:YouTube; flashlight:on; volume:up; settings:wifi; open_url:https://..." (steps run in order). */
    private suspend fun runRoutine(spec: String): String {
        val out = mutableListOf<String>()
        for (raw in spec.split(";")) {
            val step = raw.trim(); if (step.isEmpty()) continue
            val key = step.substringBefore(":").trim().lowercase(); val v = step.substringAfter(":", "").trim()
            val call = when (key) {
                "open_app" -> ToolCall("r", "open_app", JSONObject().put("name", v))
                "open_url" -> ToolCall("r", "open_url", JSONObject().put("url", v))
                "flashlight" -> ToolCall("r", "flashlight", JSONObject().put("on", v.lowercase() == "on"))
                "volume" -> ToolCall("r", "set_volume", JSONObject().put("action", v))
                "settings" -> ToolCall("r", "open_settings", JSONObject().put("page", v))
                else -> { out += "✗ '$key' step supported nahi hai"; continue }
            }
            val r = registry.execute(call)
            out += (if (r.success) "✓ " else "✗ ") + r.message
        }
        return if (out.isEmpty()) "Routine khaali hai." else out.joinToString("\n")
    }

    private fun deliver(answer: String?) {
        val s = settings.current
        if (!s.speakReplies || answer.isNullOrBlank()) { afterSpeaking(); return }
        val clean = SpeechOutput.cleanForSpeech(answer)
        val lang = if (s.speakLang == "auto") SpeechOutput.detectLanguage(clean) else s.speakLang
        if (!speechOut.supports(lang)) {
            _ui.update { it.copy(error = "Phone mein '$lang' ki text-to-speech voice installed nahi hai. Phone Settings → Text-to-speech se voice data download karein.") }
            afterSpeaking(); return
        }
        _ui.update { it.copy(phase = Phase.SPEAKING, status = "") }
        val err = speechOut.speak(clean, lang, s.ttsRate, s.ttsPitch, s.ttsVoice) { viewModelScope.launch { if (_ui.value.phase == Phase.SPEAKING) afterSpeaking() } }
        if (err != null) { _ui.update { it.copy(error = err) }; afterSpeaking() }
    }

    private fun afterSpeaking() {
        setPhase(Phase.IDLE)
        if (_ui.value.handsFree) startListening()
    }

    private fun fail(msg: String?) {
        _ui.update { it.copy(phase = Phase.IDLE, error = msg ?: "Unknown error", status = "") }
        if (_ui.value.handsFree) disableHandsFree()
    }

    private fun setPhase(p: Phase) { _ui.update { it.copy(phase = p, status = "") }; if (p != Phase.LISTENING) level.value = 0f }
    fun dismissError() { _ui.update { it.copy(error = null) } }

    // ------------------------------------------------------------------ History
    private fun persist() {
        if (!settings.current.saveHistory) return
        val st = _ui.value
        val title = st.messages.firstOrNull { it.role == Role.USER }?.text?.take(40) ?: "Chat"
        val conv = Conversation(st.conversationId, title, System.currentTimeMillis(), st.messages)
        viewModelScope.launch(Dispatchers.IO) { container.conversations.save(conv) }
    }

    fun newChat() {
        job?.cancel(); speechOut.stop(); speechIn.cancel()
        _ui.value = UiState(conversationId = container.conversations.newId(), handsFree = false)
    }

    fun openConversation(id: String) {
        viewModelScope.launch {
            val c = withContext(Dispatchers.IO) { container.conversations.load(id) } ?: return@launch
            job?.cancel(); speechOut.stop(); speechIn.cancel()
            _ui.value = UiState(conversationId = c.id, messages = c.messages)
        }
    }

    fun refreshHistory(query: String = "") {
        viewModelScope.launch { history.value = withContext(Dispatchers.IO) { container.conversations.search(query) } }
    }

    fun deleteConversation(id: String, query: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { container.conversations.delete(id) }
            if (id == _ui.value.conversationId) newChat()
            refreshHistory(query)
        }
    }

    fun deleteAllConversations() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { container.conversations.deleteAll() }
            newChat(); refreshHistory()
        }
    }

    // ------------------------------------------------------------------ Settings helpers
    fun testConnection() {
        viewModelScope.launch {
            testStatus.value = "Testing…"
            testStatus.value = try {
                ProviderFactory.create(settings.current).chat("Reply with the single word: ok", listOf(ChatMessage(Role.USER, "ping")), emptyList())
                "✓ Connection theek hai — provider ne jawab diya."
            } catch (e: AiError) { "✗ ${e.message}" }
            catch (e: NetworkException) { "✗ ${e.message}" }
            catch (e: Exception) { "✗ Test fail hua (${e.javaClass.simpleName})." }
        }
    }

    fun voices(): List<Voice> {
        val s = settings.current
        return speechOut.voicesFor(if (s.speakLang == "auto") s.recognitionLang else s.speakLang)
    }

    fun testVoice() {
        val s = settings.current
        val lang = if (s.speakLang == "auto") s.recognitionLang else s.speakLang
        val text = if (lang.startsWith("hi")) "नमस्ते, मैं ${s.assistantName} हूँ। मैं आपकी मदद के लिए तैयार हूँ।" else "Hello, I am ${s.assistantName}. I am ready to help."
        if (!speechOut.supports(lang)) { _ui.update { it.copy(error = "Is bhasha ki TTS voice installed nahi hai (Phone Settings → Text-to-speech).") }; return }
        speechOut.speak(text, lang, s.ttsRate, s.ttsPitch, s.ttsVoice) {}
    }

    override fun onCleared() { speechIn.cancel(); speechOut.shutdown() }
}
