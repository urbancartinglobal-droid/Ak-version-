package com.adai.assistant.core

import com.adai.assistant.ai.AiProvider
import kotlin.coroutines.cancellation.CancellationException

/**
 * Runs the model <-> tool loop: send conversation, execute requested tools, feed results back,
 * until the model produces a final text answer. Returns only the NEW messages produced.
 */
class Orchestrator(
    private val provider: AiProvider,
    private val tools: ToolRunner,
    private val maxSteps: Int = 6,
) {
    suspend fun respond(
        system: String,
        history: List<ChatMessage>,
        onStatus: (String) -> Unit = {},
    ): List<ChatMessage> {
        val produced = mutableListOf<ChatMessage>()
        var convo = trimHistory(history)
        repeat(maxSteps) {
            onStatus("Soch raha hoon…")
            val reply = provider.chat(system, convo, tools.specs)
            val assistant = ChatMessage(Role.ASSISTANT, reply.text, reply.toolCalls, providerRaw = reply.providerRaw)
            produced += assistant
            convo = convo + assistant
            if (reply.toolCalls.isEmpty()) return produced
            for (call in reply.toolCalls) {
                onStatus("Tool: ${call.name}")
                val result = try {
                    tools.execute(call)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    ToolResult.fail("${call.name} failed: ${e.javaClass.simpleName}")
                }
                val msg = ChatMessage(Role.TOOL, result.toModelText(), toolCallId = call.id, toolName = call.name)
                produced += msg
                convo = convo + msg
            }
        }
        produced += ChatMessage(Role.ASSISTANT, "Maaf kijiye, yeh kaam poora nahi ho paaya (bahut saare steps). Kripya dobara try karein.")
        return produced
    }

    companion object {
        /** Keeps the last [max] messages, always starting at a USER message so tool-call pairs are never orphaned. */
        fun trimHistory(h: List<ChatMessage>, max: Int = 30): List<ChatMessage> {
            if (h.size <= max) return h
            val tail = h.takeLast(max)
            val firstUser = tail.indexOfFirst { it.role == Role.USER }
            return if (firstUser >= 0) tail.drop(firstUser) else tail
        }
    }
}
