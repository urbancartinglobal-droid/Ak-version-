package com.adai.assistant.tools

import com.adai.assistant.core.ToolParam
import com.adai.assistant.core.ToolResult

/** Tools backed by live internet providers. Each returns data with fetch time + sources, or an honest error. */
fun liveTools(): List<Tool> = listOf(

    tool("get_weather", "Get LIVE current weather and a 3-day forecast for a city. If no city is given, the user's configured home city is used.",
        listOf(ToolParam("city", "string", "City name in Latin script, e.g. 'Prayagraj'"))) { a, c ->
        val city = a.str("city").ifEmpty { c.settings().homeCity }
        if (city.isEmpty()) return@tool ToolResult.fail("City batayein, ya Settings → Live Data mein home city set karein.")
        ToolResult.ok(c.live.weather(city).toModelText())
    },

    tool("get_news", "Get LIVE news headlines (top stories, or about a topic).",
        listOf(ToolParam("topic", "string", "Optional topic/keywords"), ToolParam("language", "string", "hi or en", false, listOf("hi", "en")))) { a, c ->
        val hindi = a.str("language").ifEmpty { "hi" } == "hi"
        ToolResult.ok(c.live.news(a.str("topic").ifEmpty { null }, hindi).toModelText())
    },

    tool("web_search", "Search the web for current information, sports scores/schedules, product prices, government information, etc. Returns snippets with source URLs.",
        listOf(ToolParam("query", "string", "Search query", true))) { a, c ->
        ToolResult.ok(c.live.search(a.str("query")).toModelText())
    },

    tool("exchange_rate", "Get a LIVE currency exchange rate / convert an amount (ECB reference rates).",
        listOf(ToolParam("from", "string", "ISO currency code e.g. USD", true), ToolParam("to", "string", "ISO currency code e.g. INR", true),
            ToolParam("amount", "number", "Amount to convert (default 1)"))) { a, c ->
        val amt = if (a.hasVal("amount")) a.optDouble("amount", 1.0) else 1.0
        ToolResult.ok(c.live.exchange(a.str("from"), a.str("to"), amt).toModelText())
    },

    tool("wikipedia", "Look up general knowledge on Wikipedia.",
        listOf(ToolParam("query", "string", "Topic", true), ToolParam("language", "string", "hi or en", false, listOf("hi", "en")))) { a, c ->
        ToolResult.ok(c.live.wikipedia(a.str("query"), a.str("language") == "hi").toModelText())
    },
)
