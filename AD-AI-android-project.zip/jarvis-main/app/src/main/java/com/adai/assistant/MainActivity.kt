package com.adai.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.adai.assistant.ui.AdAiTheme
import com.adai.assistant.ui.AppRoot
import com.adai.assistant.ui.AppViewModel

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private var permissionCallback: ((Boolean) -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionCallback?.invoke(granted)
        permissionCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.permissionLauncher = { permission, cb ->
            permissionCallback = cb
            permissionLauncher.launch(permission)
        }
        setContent { AdAiTheme { AppRoot(vm) } }
    }
}
