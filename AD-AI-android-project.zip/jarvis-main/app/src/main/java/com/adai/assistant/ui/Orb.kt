package com.adai.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

/** The animated assistant orb. Tap = start/stop listening (or interrupt speech). */
@Composable
fun Orb(phase: Phase, level: Float, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(if (phase == Phase.LISTENING) 900 else 2200, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    val color = when (phase) {
        Phase.IDLE -> JarvisCyan
        Phase.LISTENING -> JarvisGreen
        Phase.THINKING -> JarvisViolet
        Phase.SPEAKING -> JarvisCyan
    }
    val desc = when (phase) {
        Phase.IDLE -> "Microphone. Tap to speak"
        Phase.LISTENING -> "Listening. Tap to stop"
        Phase.THINKING -> "Thinking. Tap to cancel"
        Phase.SPEAKING -> "Speaking. Tap to interrupt"
    }
    Canvas(
        modifier.size(150.dp).clickable(onClick = onClick).semantics { contentDescription = desc },
    ) {
        val base = size.minDimension / 3.2f
        val extra = base * (0.12f * pulse + 0.6f * level)
        drawCircle(color.copy(alpha = 0.10f), radius = base + extra * 2.2f)
        drawCircle(color.copy(alpha = 0.22f), radius = base + extra)
        drawCircle(color, radius = base * 0.9f, style = Stroke(width = 4.dp.toPx()))
        drawCircle(color.copy(alpha = 0.85f), radius = base * 0.38f)
    }
}
