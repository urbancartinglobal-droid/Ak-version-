package com.adai.assistant.ai

import com.adai.assistant.core.AiReply
import com.adai.assistant.core.ChatMessage
import com.adai.assistant.core.ToolSpec

/**
 * A pluggable LLM backend. To add a provider: implement this interface and register it in [ProviderFactory].
 * Providers must be stateless; the full conversation is passed on every call.
 */
interface AiProvider {
    suspend fun chat(system: String, messages: List<ChatMessage>, tools: List<ToolSpec>): AiReply
}
