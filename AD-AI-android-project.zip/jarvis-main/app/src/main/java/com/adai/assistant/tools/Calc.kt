package com.adai.assistant.tools

/** Small safe arithmetic evaluator: + - * / ^ % (postfix percent), parentheses, unary minus. */
object Calc {
    fun eval(src: String): Double {
        val clean = src.replace("×", "*").replace("÷", "/").replace(",", "").replace(" ", "").replace("x", "*")
        if (clean.isEmpty()) throw IllegalArgumentException("Empty expression")
        val p = Parser(clean)
        val v = p.expr()
        if (p.i != clean.length) throw IllegalArgumentException("Unexpected '${clean[p.i]}'")
        return v
    }

    fun format(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "undefined"
        return if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else java.math.BigDecimal(v).setScale(6, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var i = 0
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = unary()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val r = unary()
                if (op == '/' && r == 0.0) throw IllegalArgumentException("Division by zero")
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return power()
        }
        fun power(): Double {
            val b = atom()
            if (i < s.length && s[i] == '^') { i++; return Math.pow(b, unary()) }
            return b
        }
        fun atom(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("Missing )")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("Number expected")
            val v = s.substring(st, i).toDoubleOrNull() ?: throw IllegalArgumentException("Bad number")
            if (i < s.length && s[i] == '%') { i++; return v / 100 }
            return v
        }
    }
}
