package com.adai.assistant.ai

import com.adai.assistant.core.AiError
import com.adai.assistant.core.AiReply
import com.adai.assistant.core.ChatMessage
import com.adai.assistant.core.Role
import com.adai.assistant.core.ToolCall
import com.adai.assistant.core.ToolSpec
import org.json.JSONArray
import org.json.JSONObject

/** Works with any service exposing the OpenAI "chat/completions" API (OpenAI, Groq, OpenRouter, ...). */
class OpenAiCompatibleProvider(
    private val baseUrl: String,
    private val apiKey: String,
    private val model: String,
) : AiProvider {

    override suspend fun chat(system: String, messages: List<ChatMessage>, tools: List<ToolSpec>): AiReply {
        val body = buildRequest(system, messages, tools)
        val res = Http.postJson(
            baseUrl.trimEnd('/') + "/chat/completions",
            body,
            mapOf("Authorization" to "Bearer $apiKey"),
        )
        if (res.code !in 200..299) throw mapHttpError(res.code, res.body, model, apiKey)
        return parse(res.body)
    }

    internal fun buildRequest(system: String, messages: List<ChatMessage>, tools: List<ToolSpec>): JSONObject {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        for (m in messages) {
            when (m.role) {
                Role.USER -> msgs.put(JSONObject().put("role", "user").put("content", m.text))
                Role.ASSISTANT -> {
                    val o = JSONObject().put("role", "assistant")
                    o.put("content", if (m.text.isEmpty()) JSONObject.NULL else m.text)
                    if (m.toolCalls.isNotEmpty()) {
                        val arr = JSONArray()
                        m.toolCalls.forEach { c ->
                            arr.put(
                                JSONObject().put("id", c.id).put("type", "function").put(
                                    "function",
                                    JSONObject().put("name", c.name).put("arguments", c.args.toString()),
                                ),
                            )
                        }
                        o.put("tool_calls", arr)
                    }
                    msgs.put(o)
                }
                Role.TOOL -> msgs.put(
                    JSONObject().put("role", "tool").put("tool_call_id", m.toolCallId ?: "").put("content", m.text),
                )
                Role.SYSTEM -> Unit
            }
        }
        val req = JSONObject().put("model", model).put("messages", msgs)
        if (tools.isNotEmpty()) {
            val arr = JSONArray()
            tools.forEach { t ->
                arr.put(
                    JSONObject().put("type", "function").put(
                        "function",
                        JSONObject().put("name", t.name).put("description", t.description).put("parameters", t.schema()),
                    ),
                )
            }
            req.put("tools", arr)
        }
        return req
    }

    internal fun parse(body: String): AiReply {
        val root = try { JSONObject(body) } catch (e: Exception) { throw AiError.BadResponse("invalid JSON") }
        val choices = root.optJSONArray("choices")
        if (choices == null || choices.length() == 0) throw AiError.BadResponse("no choices")
        val msg = choices.getJSONObject(0).optJSONObject("message") ?: throw AiError.BadResponse("no message")
        val text = if (msg.isNull("content")) "" else msg.optString("content", "")
        val calls = mutableListOf<ToolCall>()
        val tc = msg.optJSONArray("tool_calls")
        if (tc != null) {
            for (i in 0 until tc.length()) {
                val c = tc.getJSONObject(i)
                val fn = c.optJSONObject("function") ?: continue
                val args = try { JSONObject(fn.optString("arguments", "{}").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
                calls += ToolCall(c.optString("id", "call_$i"), fn.getString("name"), args)
            }
        }
        return AiReply(text.trim(), calls)
    }
}
