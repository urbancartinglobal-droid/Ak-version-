package com.adai.assistant.core

import org.json.JSONArray
import org.json.JSONObject

enum class Role { SYSTEM, USER, ASSISTANT, TOOL }

data class ToolCall(val id: String, val name: String, val args: JSONObject)

data class ChatMessage(
    val role: Role,
    val text: String = "",
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null,
    /** Opaque provider data that must be echoed back verbatim (e.g. Gemini thought signatures). */
    val providerRaw: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("role", role.name)
        put("text", text)
        put("ts", timestamp)
        toolCallId?.let { put("toolCallId", it) }
        toolName?.let { put("toolName", it) }
        providerRaw?.let { put("raw", it) }
        if (toolCalls.isNotEmpty()) {
            val arr = JSONArray()
            toolCalls.forEach { c ->
                arr.put(JSONObject().put("id", c.id).put("name", c.name).put("args", c.args))
            }
            put("calls", arr)
        }
    }

    companion object {
        fun fromJson(o: JSONObject): ChatMessage {
            val calls = mutableListOf<ToolCall>()
            val arr = o.optJSONArray("calls")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    calls += ToolCall(c.getString("id"), c.getString("name"), c.optJSONObject("args") ?: JSONObject())
                }
            }
            return ChatMessage(
                role = Role.valueOf(o.getString("role")),
                text = o.optString("text", ""),
                toolCalls = calls,
                toolCallId = if (o.has("toolCallId")) o.getString("toolCallId") else null,
                toolName = if (o.has("toolName")) o.getString("toolName") else null,
                providerRaw = if (o.has("raw")) o.getString("raw") else null,
                timestamp = o.optLong("ts", System.currentTimeMillis()),
            )
        }
    }
}

data class ToolParam(
    val name: String,
    val type: String, // "string" | "number" | "integer" | "boolean"
    val description: String,
    val required: Boolean = false,
    val enum: List<String>? = null,
)

data class ToolSpec(val name: String, val description: String, val params: List<ToolParam> = emptyList()) {
    fun schema(): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        for (p in params) {
            val o = JSONObject().put("type", p.type).put("description", p.description)
            p.enum?.let { e -> o.put("enum", JSONArray(e)) }
            props.put(p.name, o)
            if (p.required) req.put(p.name)
        }
        val s = JSONObject().put("type", "object").put("properties", props)
        if (req.length() > 0) s.put("required", req)
        return s
    }
}

data class AiReply(val text: String, val toolCalls: List<ToolCall>, val providerRaw: String? = null)

data class ToolResult(val success: Boolean, val message: String) {
    fun toModelText(): String = if (success) "OK: $message" else "ERROR: $message"

    companion object {
        fun ok(msg: String) = ToolResult(true, msg)
        fun fail(msg: String) = ToolResult(false, msg)
    }
}

/** User-presentable AI errors (Hinglish). Never include API keys. */
sealed class AiError(message: String) : Exception(message) {
    class MissingKey : AiError("API key set nahi hai. Settings → AI Brain mein apni key daalein. (No API key configured.)")
    class InvalidKey : AiError("API key galat ya expire hai. Settings mein check karein. (Invalid or expired API key.)")
    class OutOfCredits : AiError("Provider account mein credits/quota khatam ho gaya hai. (Out of credits or quota.)")
    class RateLimited : AiError("Bahut zyada requests ya limit poori ho gayi. Thodi der baad try karein. (Rate limited.)")
    class ModelNotFound(model: String) : AiError("Model '$model' nahi mila. Settings mein model name check karein. (Model not found.)")
    class Blocked(why: String) : AiError("Provider ne is request ko block kiya: $why")
    class Server(code: Int, detail: String) : AiError("Provider error ($code): $detail")
    class BadResponse(detail: String) : AiError("Provider ka jawab samajh nahi aaya: $detail")
}

class NetworkException(message: String) : Exception(message)

/** Executes tools requested by the model. Implemented by ToolRegistry (and fakes in tests). */
interface ToolRunner {
    val specs: List<ToolSpec>
    suspend fun execute(call: ToolCall): ToolResult
}
