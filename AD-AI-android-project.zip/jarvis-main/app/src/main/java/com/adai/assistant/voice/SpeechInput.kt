package com.adai.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Speech-to-text using Android's SpeechRecognizer. Must be used from the main thread. */
class SpeechInput(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null

    val available: Boolean get() = SpeechRecognizer.isRecognitionAvailable(context)

    /**
     * @param onFail (message, silent) — silent=true for "no speech heard" type errors (not worth a red banner).
     */
    fun start(
        language: String,
        onPartial: (String) -> Unit,
        onResult: (String) -> Unit,
        onFail: (String, Boolean) -> Unit,
        onLevel: (Float) -> Unit,
    ) {
        cancel()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isBlank()) onFail("Kuch sunai nahi diya.", true) else onResult(t)
            }
            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> onFail("Kuch sunai nahi diya. Dobara bolein.", true)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> onFail("Microphone permission nahi hai. Permissions screen se allow karein.", false)
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> onFail("Speech recognition ke liye network problem. Internet check karein (ya offline Hindi voice pack install karein).", false)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> onFail("Speech recognizer busy hai. Ek second baad try karein.", false)
                    SpeechRecognizer.ERROR_AUDIO -> onFail("Audio record karne mein problem aayi (microphone kisi aur app mein busy ho sakta hai).", false)
                    SpeechRecognizer.ERROR_SERVER -> onFail("Speech service ka server error. Thodi der baad try karein.", false)
                    12, 13 -> onFail("Yeh bhasha speech recognition mein available nahi hai. Settings mein language badlein ya Google app mein language pack download karein.", false)
                    else -> onFail("Speech recognition error (code $error).", false)
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        r.startListening(i)
    }

    /** Stop recording and deliver what was heard so far. */
    fun stop() { recognizer?.stopListening() }

    fun cancel() {
        recognizer?.apply { cancel(); destroy() }
        recognizer = null
    }
}
