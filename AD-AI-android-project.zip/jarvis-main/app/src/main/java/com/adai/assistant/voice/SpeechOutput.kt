package com.adai.assistant.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID

/** Text-to-speech with language, voice, rate and pitch control, and interruption. */
class SpeechOutput(context: Context) {
    private var ready = false
    private var initFailed = false
    private var pending: (() -> Unit)? = null
    private var tts: TextToSpeech? = null
    @Volatile private var lastId: String = ""

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) { ready = true; pending?.invoke() } else initFailed = true
            pending = null
        }
    }

    companion object {
        /** Picks hi-IN when the text is mostly Devanagari, otherwise the given English tag. */
        fun detectLanguage(text: String, english: String = "en-IN"): String {
            val letters = text.count { it.isLetter() }
            if (letters == 0) return "hi-IN"
            val deva = text.count { it in '\u0900'..'\u097F' }
            return if (deva * 100 / letters >= 30) "hi-IN" else english
        }

        fun cleanForSpeech(t: String): String = t
            .replace(Regex("https?://\\S+"), " link ")
            .replace(Regex("[*_#`>~]+"), "")
            .replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1")
            .replace(Regex("\\s+"), " ").trim()

        fun chunk(text: String, max: Int = 3000): List<String> {
            if (text.length <= max) return listOf(text)
            val out = mutableListOf<String>()
            var rest = text
            while (rest.length > max) {
                var cut = rest.lastIndexOfAny(charArrayOf('.', '।', '!', '?', '\n'), max)
                if (cut < max / 2) cut = max
                out += rest.substring(0, cut + 1)
                rest = rest.substring(minOf(cut + 1, rest.length))
            }
            if (rest.isNotBlank()) out += rest
            return out
        }
    }

    /** @return null if speaking started (or was queued), otherwise a user-facing error. */
    fun speak(text: String, languageTag: String, rate: Float, pitch: Float, voiceName: String, onFinished: () -> Unit): String? {
        if (initFailed) return "Text-to-speech engine start nahi hua."
        val run = {
            val t = tts!!
            val loc = Locale.forLanguageTag(languageTag)
            val r = t.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                onFinished()
            } else {
                if (voiceName.isNotEmpty()) t.voices?.firstOrNull { it.name == voiceName && it.locale.language == loc.language }?.let { t.voice = it }
                t.setSpeechRate(rate.coerceIn(0.3f, 3f))
                t.setPitch(pitch.coerceIn(0.3f, 2f))
                val parts = chunk(text)
                val base = UUID.randomUUID().toString()
                lastId = "$base-${parts.size - 1}"
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) { if (utteranceId == lastId) onFinished() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { if (utteranceId == lastId) onFinished() }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) = Unit
                })
                parts.forEachIndexed { idx, p ->
                    t.speak(p, if (idx == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(), "$base-$idx")
                }
            }
        }
        if (ready) run() else pending = run
        return null
    }

    /** True if the device TTS has voice data for this language. */
    fun supports(languageTag: String): Boolean {
        val t = tts ?: return false
        if (!ready) return true
        val r = t.isLanguageAvailable(Locale.forLanguageTag(languageTag))
        return r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
    }

    fun voicesFor(languageTag: String): List<Voice> {
        val lang = Locale.forLanguageTag(languageTag).language
        return try { tts?.voices?.filter { it.locale.language == lang }?.sortedBy { it.name } ?: emptyList() } catch (e: Exception) { emptyList() }
    }

    fun stop() { lastId = ""; tts?.stop() }
    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}
