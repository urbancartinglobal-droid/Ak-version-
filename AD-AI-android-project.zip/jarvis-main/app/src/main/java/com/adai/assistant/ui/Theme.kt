package com.adai.assistant.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val JarvisCyan = Color(0xFF00E5FF)
val JarvisGreen = Color(0xFF69F0AE)
val JarvisViolet = Color(0xFF7C4DFF)

private val JarvisColors = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = Color(0xFF00363D),
    primaryContainer = Color(0xFF0B3A47),
    onPrimaryContainer = Color(0xFFD6F8FF),
    secondary = JarvisViolet,
    background = Color(0xFF0A0F1A),
    onBackground = Color(0xFFE6F1FF),
    surface = Color(0xFF0F1626),
    onSurface = Color(0xFFE6F1FF),
    surfaceVariant = Color(0xFF16233A),
    onSurfaceVariant = Color(0xFFA9BCD6),
    error = Color(0xFFFF6B6B),
    errorContainer = Color(0xFF4A1F24),
    onErrorContainer = Color(0xFFFFDAD6),
)

/** Dark Jarvis theme (the app is intentionally dark-only: high contrast, battery-friendly on OLED). */
@Composable
fun AdAiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = JarvisColors, content = content)
}
