package com.adai.assistant.data

import com.adai.assistant.core.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Item(val id: String, val text: String, val ts: Long, val kind: String = "", val extra: String = "")

/** Tiny JSON-file-backed list used for memory facts, notes/reminders and custom commands. Replaceable with Room later. */
class ItemStore(private val file: File) {
    private val _items = MutableStateFlow(read())
    val items: StateFlow<List<Item>> = _items

    @Synchronized
    fun add(text: String, kind: String = "", extra: String = ""): Item {
        val it = Item(UUID.randomUUID().toString(), text.trim(), System.currentTimeMillis(), kind, extra)
        write(_items.value + it)
        return it
    }

    @Synchronized fun remove(id: String) = write(_items.value.filterNot { it.id == id })
    @Synchronized fun clear() = write(emptyList())

    private fun write(list: List<Item>) {
        _items.value = list
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("ts", it.ts).put("kind", it.kind).put("extra", it.extra)) }
        file.parentFile?.mkdirs()
        file.writeText(arr.toString())
    }

    private fun read(): List<Item> = try {
        if (!file.exists()) emptyList() else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Item(o.getString("id"), o.getString("text"), o.optLong("ts"), o.optString("kind"), o.optString("extra"))
            }
        }
    } catch (e: Exception) { emptyList() }
}

data class Conversation(val id: String, val title: String, val updated: Long, val messages: List<ChatMessage>)

/** One JSON file per conversation in app-private storage. */
class ConversationStore(private val dir: File) {
    init { dir.mkdirs() }

    fun newId(): String = UUID.randomUUID().toString()

    fun save(c: Conversation) {
        val arr = JSONArray()
        c.messages.forEach { arr.put(it.toJson()) }
        File(dir, "${c.id}.json").writeText(
            JSONObject().put("id", c.id).put("title", c.title).put("updated", c.updated).put("messages", arr).toString(),
        )
    }

    fun load(id: String): Conversation? = readFile(File(dir, "$id.json"))

    fun list(): List<Conversation> =
        (dir.listFiles { f -> f.extension == "json" } ?: emptyArray()).mapNotNull { readFile(it) }.sortedByDescending { it.updated }

    fun search(q: String): List<Conversation> {
        val needle = q.trim().lowercase()
        if (needle.isEmpty()) return list()
        return list().filter { c -> c.title.lowercase().contains(needle) || c.messages.any { it.text.lowercase().contains(needle) } }
    }

    fun delete(id: String) { File(dir, "$id.json").delete() }
    fun deleteAll() { dir.listFiles()?.forEach { it.delete() } }

    private fun readFile(f: File): Conversation? = try {
        val o = JSONObject(f.readText())
        val arr = o.getJSONArray("messages")
        Conversation(o.getString("id"), o.optString("title"), o.optLong("updated"), (0 until arr.length()).map { ChatMessage.fromJson(arr.getJSONObject(it)) })
    } catch (e: Exception) { null }
}
