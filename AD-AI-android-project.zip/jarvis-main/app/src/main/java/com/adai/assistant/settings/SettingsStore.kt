package com.adai.assistant.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class AppSettings(
    val assistantName: String = "AD AI",
    val provider: String = "gemini",            // gemini | openai_compat
    val model: String = "gemini-2.5-flash",     // editable; model names change over time
    val baseUrl: String = "https://api.openai.com/v1",
    val apiKey: String = "",                     // stored encrypted
    val recognitionLang: String = "hi-IN",
    val speakLang: String = "auto",              // auto | hi-IN | en-IN | en-US
    val ttsVoice: String = "",
    val ttsRate: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val speakReplies: Boolean = true,
    val personality: String = "jarvis",          // jarvis | friendly | custom
    val customPersonality: String = "",
    val homeCity: String = "",
    val tavilyKey: String = "",                  // stored encrypted
    val memoryEnabled: Boolean = true,
    val saveHistory: Boolean = true,
    val offlineCommands: Boolean = true,
    val fileTreeUri: String = "",
)

/** Non-secret values live in normal SharedPreferences; API keys live in EncryptedSharedPreferences (Android Keystore). */
class SettingsStore(private val context: Context) {
    private val plain: SharedPreferences = context.getSharedPreferences("adai_prefs", Context.MODE_PRIVATE)
    private val secure: SharedPreferences = createSecure()

    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state
    val current: AppSettings get() = _state.value

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_state.value)
        save(next)
        _state.value = next
    }

    fun deleteSecrets() = update { it.copy(apiKey = "", tavilyKey = "") }

    private fun createSecure(): SharedPreferences {
        fun build(): SharedPreferences {
            val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, "adai_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        }
        return try {
            build()
        } catch (e: Exception) {
            // Keystore invalidated (e.g. restore/lock change): reset the secure file and start clean.
            context.deleteSharedPreferences("adai_secure")
            build()
        }
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            assistantName = plain.getString("assistantName", d.assistantName) ?: d.assistantName,
            provider = plain.getString("provider", d.provider) ?: d.provider,
            model = plain.getString("model", d.model) ?: d.model,
            baseUrl = plain.getString("baseUrl", d.baseUrl) ?: d.baseUrl,
            apiKey = secure.getString("apiKey", "") ?: "",
            recognitionLang = plain.getString("recognitionLang", d.recognitionLang) ?: d.recognitionLang,
            speakLang = plain.getString("speakLang", d.speakLang) ?: d.speakLang,
            ttsVoice = plain.getString("ttsVoice", "") ?: "",
            ttsRate = plain.getFloat("ttsRate", d.ttsRate),
            ttsPitch = plain.getFloat("ttsPitch", d.ttsPitch),
            speakReplies = plain.getBoolean("speakReplies", d.speakReplies),
            personality = plain.getString("personality", d.personality) ?: d.personality,
            customPersonality = plain.getString("customPersonality", "") ?: "",
            homeCity = plain.getString("homeCity", "") ?: "",
            tavilyKey = secure.getString("tavilyKey", "") ?: "",
            memoryEnabled = plain.getBoolean("memoryEnabled", d.memoryEnabled),
            saveHistory = plain.getBoolean("saveHistory", d.saveHistory),
            offlineCommands = plain.getBoolean("offlineCommands", d.offlineCommands),
            fileTreeUri = plain.getString("fileTreeUri", "") ?: "",
        )
    }

    private fun save(s: AppSettings) {
        plain.edit()
            .putString("assistantName", s.assistantName)
            .putString("provider", s.provider)
            .putString("model", s.model)
            .putString("baseUrl", s.baseUrl)
            .putString("recognitionLang", s.recognitionLang)
            .putString("speakLang", s.speakLang)
            .putString("ttsVoice", s.ttsVoice)
            .putFloat("ttsRate", s.ttsRate)
            .putFloat("ttsPitch", s.ttsPitch)
            .putBoolean("speakReplies", s.speakReplies)
            .putString("personality", s.personality)
            .putString("customPersonality", s.customPersonality)
            .putString("homeCity", s.homeCity)
            .putBoolean("memoryEnabled", s.memoryEnabled)
            .putBoolean("saveHistory", s.saveHistory)
            .putBoolean("offlineCommands", s.offlineCommands)
            .putString("fileTreeUri", s.fileTreeUri)
            .apply()
        secure.edit().putString("apiKey", s.apiKey).putString("tavilyKey", s.tavilyKey).apply()
    }
}
