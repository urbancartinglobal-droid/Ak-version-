package com.adai.assistant.ai

import com.adai.assistant.core.AiError
import com.adai.assistant.core.AiReply
import com.adai.assistant.core.ChatMessage
import com.adai.assistant.core.Role
import com.adai.assistant.core.ToolCall
import com.adai.assistant.core.ToolSpec
import org.json.JSONArray
import org.json.JSONObject

/** Google Gemini via the generateContent REST API (key is sent in a header, never in the URL). */
class GeminiProvider(
    private val apiKey: String,
    private val model: String,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta",
) : AiProvider {

    override suspend fun chat(system: String, messages: List<ChatMessage>, tools: List<ToolSpec>): AiReply {
        val res = Http.postJson(
            "${baseUrl.trimEnd('/')}/models/$model:generateContent",
            buildRequest(system, messages, tools),
            mapOf("x-goog-api-key" to apiKey),
        )
        if (res.code !in 200..299) throw mapHttpError(res.code, res.body, model, apiKey)
        return parse(res.body)
    }

    internal fun buildRequest(system: String, messages: List<ChatMessage>, tools: List<ToolSpec>): JSONObject {
        val contents = JSONArray()
        var lastWasToolResponses = false
        for (m in messages) {
            when (m.role) {
                Role.USER -> {
                    contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", m.text))))
                    lastWasToolResponses = false
                }
                Role.ASSISTANT -> {
                    val raw = m.providerRaw?.let { try { JSONObject(it) } catch (e: Exception) { null } }
                    if (raw != null) {
                        contents.put(raw)
                    } else {
                        val parts = JSONArray()
                        if (m.text.isNotEmpty()) parts.put(JSONObject().put("text", m.text))
                        m.toolCalls.forEach { c ->
                            parts.put(JSONObject().put("functionCall", JSONObject().put("name", c.name).put("args", c.args)))
                        }
                        if (parts.length() == 0) parts.put(JSONObject().put("text", ""))
                        contents.put(JSONObject().put("role", "model").put("parts", parts))
                    }
                    lastWasToolResponses = false
                }
                Role.TOOL -> {
                    val part = JSONObject().put(
                        "functionResponse",
                        JSONObject().put("name", m.toolName ?: "tool").put("response", JSONObject().put("result", m.text)),
                    )
                    if (lastWasToolResponses) {
                        contents.getJSONObject(contents.length() - 1).getJSONArray("parts").put(part)
                    } else {
                        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(part)))
                    }
                    lastWasToolResponses = true
                }
                Role.SYSTEM -> Unit
            }
        }
        val req = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        if (tools.isNotEmpty()) {
            val decls = JSONArray()
            tools.forEach { t ->
                val d = JSONObject().put("name", t.name).put("description", t.description)
                if (t.params.isNotEmpty()) d.put("parameters", t.schema())
                decls.put(d)
            }
            req.put("tools", JSONArray().put(JSONObject().put("function_declarations", decls)))
        }
        return req
    }

    internal fun parse(body: String): AiReply {
        val root = try { JSONObject(body) } catch (e: Exception) { throw AiError.BadResponse("invalid JSON") }
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val why = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            if (why.isNotEmpty()) throw AiError.Blocked(why)
            throw AiError.BadResponse("no candidates")
        }
        val content = cands.getJSONObject(0).optJSONObject("content")
            ?: throw AiError.BadResponse("empty response (finishReason=${cands.getJSONObject(0).optString("finishReason")})")
        val parts = content.optJSONArray("parts") ?: JSONArray()
        val text = StringBuilder()
        val calls = mutableListOf<ToolCall>()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            if (p.has("text")) text.append(p.getString("text"))
            val fc = p.optJSONObject("functionCall")
            if (fc != null) calls += ToolCall("call_$i", fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
        }
        if (!content.has("role")) content.put("role", "model")
        return AiReply(text.toString().trim(), calls, content.toString())
    }
}
