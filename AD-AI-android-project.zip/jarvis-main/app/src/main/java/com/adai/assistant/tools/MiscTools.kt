package com.adai.assistant.tools

import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.Locale
import android.provider.AlarmClock
import androidx.documentfile.provider.DocumentFile
import com.adai.assistant.core.ToolParam
import com.adai.assistant.core.ToolResult
import com.adai.assistant.services.AdAccessibilityService
import com.adai.assistant.services.AdNotificationListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun miscTools(): List<Tool> = listOf(

    tool("calculator", "Evaluate an arithmetic expression exactly (+ - * / ^ % and parentheses).",
        listOf(ToolParam("expression", "string", "e.g. '500*18/100'", true))) { a, _ ->
        try { ToolResult.ok("${a.str("expression")} = ${Calc.format(Calc.eval(a.str("expression")))}") }
        catch (e: IllegalArgumentException) { ToolResult.fail("Expression samajh nahi aaya: ${e.message}") }
    },

    tool("create_note", "Save a note on this device (stored locally in the app).", listOf(ToolParam("text", "string", "Note text", true))) { a, c ->
        c.notes.add(a.str("text"), "note")
        ToolResult.ok("Note app mein save ho gaya (local storage).")
    },

    tool("list_notes", "List saved notes and reminders.") { _, c ->
        val items = c.notes.items.value
        if (items.isEmpty()) ToolResult.ok("Koi saved note nahi hai.")
        else ToolResult.ok(items.takeLast(20).joinToString("\n") { "- [${it.kind}] ${it.text}" })
    },

    tool("create_reminder", "Create a reminder at a clock time (24-hour) using the Clock app alarm with the reminder text as label, and also save it as a note.",
        listOf(ToolParam("text", "string", "What to be reminded about", true), ToolParam("hour", "integer", "Hour 0-23", true), ToolParam("minute", "integer", "Minute 0-59", true))) { a, c ->
        val h = a.optInt("hour", -1); val m = a.optInt("minute", -1)
        if (h !in 0..23 || m !in 0..59) return@tool ToolResult.fail("Time galat hai.")
        c.notes.add("${a.str("text")} (%02d:%02d)".format(h, m), "reminder")
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.str("text")).putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.context.startActivity(i); ToolResult.ok("Reminder note save hua aur Clock app ko %02d:%02d ka alarm-reminder set karne ki request bheji gayi (Clock app mein verify karein).".format(h, m)) }
        catch (e: Exception) { ToolResult.fail("Reminder note save hua, par Clock app alarm set nahi kar paayi.") }
    },


    tool("add_calendar_event", "Open the calendar app's new-event screen pre-filled (the user saves it there). Time format: yyyy-MM-dd HH:mm (24h, local time).",
        listOf(ToolParam("title", "string", "Event title", true), ToolParam("start", "string", "yyyy-MM-dd HH:mm", true),
            ToolParam("duration_minutes", "integer", "Default 60"), ToolParam("location", "string", "Optional place"))) { a, c ->
        val start = try { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(a.str("start"))?.time } catch (e: Exception) { null }
            ?: return@tool ToolResult.fail("Time format galat hai; 'yyyy-MM-dd HH:mm' chahiye.")
        val dur = if (a.hasVal("duration_minutes")) a.optInt("duration_minutes", 60) else 60
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, a.str("title"))
            .putExtra(CalendarContract.Events.EVENT_LOCATION, a.str("location"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + dur * 60_000L)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.context.startActivity(i); ToolResult.ok("Calendar mein event ka form khul gaya. Event abhi SAVE nahi hua; aap Save dabayein.") }
        catch (e: Exception) { ToolResult.fail("Phone mein calendar app nahi mili.") }
    },

    tool("compose_email", "Open the email app with a draft. It is NOT sent automatically; the user presses send.",
        listOf(ToolParam("to", "string", "Recipient email address"), ToolParam("subject", "string", "Subject"), ToolParam("body", "string", "Body text", true))) { a, c ->
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).putExtra(Intent.EXTRA_EMAIL, arrayOf(a.str("to")))
            .putExtra(Intent.EXTRA_SUBJECT, a.str("subject")).putExtra(Intent.EXTRA_TEXT, a.str("body")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.context.startActivity(i); ToolResult.ok("Email draft khul gaya. Bheja NAHI gaya; send aap dabayein.") }
        catch (e: Exception) { ToolResult.fail("Email app nahi mili.") }
    },

    tool("remember_fact", "Remember a fact about the user for future conversations (only when the user asks you to remember something).",
        listOf(ToolParam("fact", "string", "The fact to remember", true))) { a, c ->
        if (!c.settings().memoryEnabled) return@tool ToolResult.fail("Memory Settings mein band hai.")
        c.memory.add(a.str("fact"), "fact")
        ToolResult.ok("Yaad kar liya (aap Settings → Memory se dekh/hata sakte hain).")
    },

    tool("search_files", "Search file names inside the single folder the user authorized in Permissions. Can open the first match.",
        listOf(ToolParam("query", "string", "Part of the file name", true), ToolParam("open_first", "boolean", "Open the first match"))) { a, c ->
        val uriStr = c.settings().fileTreeUri
        if (uriStr.isEmpty()) return@tool ToolResult.fail("Pehle Permissions screen mein ek folder authorize karein.")
        val root = DocumentFile.fromTreeUri(c.context, Uri.parse(uriStr)) ?: return@tool ToolResult.fail("Authorized folder access nahi ho raha; dobara chunein.")
        val q = a.str("query").lowercase()
        val hits = mutableListOf<DocumentFile>()
        var visited = 0
        withContext(Dispatchers.IO) {
            val queue = ArrayDeque<DocumentFile>().apply { add(root) }
            while (queue.isNotEmpty() && visited < 3000 && hits.size < 10) {
                val dir = queue.removeFirst()
                for (f in dir.listFiles()) {
                    visited++
                    if (f.isDirectory) queue.add(f)
                    else if ((f.name ?: "").lowercase().contains(q)) hits.add(f)
                }
            }
        }
        if (hits.isEmpty()) return@tool ToolResult.ok("Authorized folder mein '$q' wali koi file nahi mili ($visited items dekhe).")
        var opened = ""
        if (a.optBoolean("open_first", false)) {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(hits[0].uri, hits[0].type ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            opened = try { c.context.startActivity(i); "\nPehli file open karne ki request bheji gayi." } catch (e: Exception) { "\nIs file ko kholne wali app nahi mili." }
        }
        ToolResult.ok("Mili files:\n" + hits.joinToString("\n") { "- ${it.name}" } + opened)
    },

    // ---- Accessibility-based tools (user must enable the service; each use is confirmed) ----
    tool("system_navigate", "Press a system navigation key via the accessibility service.",
        listOf(ToolParam("action", "string", "back, home, recents, notifications or quick_settings", true, listOf("back", "home", "recents", "notifications", "quick_settings")))) { a, c ->
        val svc = AdAccessibilityService.instance ?: return@tool ToolResult.fail("Accessibility service on nahi hai. Permissions screen se enable karein.")
        if (!c.ui.confirm("Phone control", "AD AI '${a.str("action")}' dabaye?")) return@tool ToolResult.fail("User ne mana kiya.")
        val ok = svc.navigate(a.str("action"))
        if (ok) ToolResult.ok("'${a.str("action")}' action Android ne accept kiya.") else ToolResult.fail("Android ne yeh action nahi kiya.")
    },

    tool("read_screen", "Read the visible text of the app currently on screen (password fields excluded). The text is sent to the AI provider.") { _, c ->
        val svc = AdAccessibilityService.instance ?: return@tool ToolResult.fail("Accessibility service on nahi hai. Permissions screen se enable karein.")
        if (!c.ui.confirm("Screen padhein?", "Screen par dikh rahe text ko AI provider ko bheja jayega. Banking/OTP screens par yeh na karein. Aage badhein?")) return@tool ToolResult.fail("User ne mana kiya.")
        val t = svc.readScreenText()
        if (t.isBlank()) ToolResult.fail("Screen par padhne layak text nahi mila (app ne access block kiya ho sakta hai).") else ToolResult.ok(t)
    },

    tool("tap_on_screen_text", "Tap a button/element in the current app by its visible label via the accessibility service.",
        listOf(ToolParam("label", "string", "Visible text of the element", true))) { a, c ->
        val svc = AdAccessibilityService.instance ?: return@tool ToolResult.fail("Accessibility service on nahi hai. Permissions screen se enable karein.")
        if (!c.ui.confirm("Screen par tap karein?", "AD AI '${a.str("label")}' par tap karega. Theek hai?")) return@tool ToolResult.fail("User ne mana kiya.")
        if (svc.clickByText(a.str("label"))) ToolResult.ok("'${a.str("label")}' par tap Android ne accept kiya (result ke liye screen dekhein).")
        else ToolResult.fail("'${a.str("label")}' naam ka tappable element screen par nahi mila.")
    },

    tool("read_notifications", "List which apps have active notifications (app name + title only; message bodies are never read). Requires notification access.") { _, c ->
        val l = AdNotificationListener.instance ?: return@tool ToolResult.fail("Notification access on nahi hai. Permissions screen se enable karein.")
        if (!c.ui.confirm("Notifications dekhein?", "Active notifications ke app naam aur title AI provider ko bheje jayenge (message ka content nahi). Theek hai?")) return@tool ToolResult.fail("User ne mana kiya.")
        val list = l.snapshot()
        if (list.isEmpty()) ToolResult.ok("Abhi koi notification nahi hai.") else ToolResult.ok(list.joinToString("\n"))
    },
)
