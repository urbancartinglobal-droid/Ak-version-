@file:OptIn(ExperimentalMaterial3Api::class)

package com.adai.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.core.app.NotificationManagerCompat
import com.adai.assistant.core.Role
import com.adai.assistant.services.AdAccessibilityService
import java.text.DateFormat
import java.util.Date

@Composable
fun AppRoot(vm: AppViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val state by vm.ui.collectAsState()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val items = listOf("Assistant" to Icons.Filled.Home, "History" to Icons.Filled.Menu, "Permissions" to Icons.Filled.Lock, "Settings" to Icons.Filled.Settings)
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> AssistantScreen(vm)
                1 -> HistoryScreen(vm) { id -> vm.openConversation(id); tab = 0 }
                2 -> PermissionsScreen()
                else -> SettingsScreen(vm)
            }
        }
    }
    state.confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { vm.answerConfirm(false) },
            title = { Text(c.title) },
            text = { Text(c.detail) },
            confirmButton = { Button(onClick = { vm.answerConfirm(true) }) { Text("Haan / Yes") } },
            dismissButton = { TextButton(onClick = { vm.answerConfirm(false) }) { Text("Nahi / No") } },
        )
    }
}

@Composable
private fun KeepScreenOn(on: Boolean) {
    val view = LocalView.current
    DisposableEffect(on) { view.keepScreenOn = on; onDispose { view.keepScreenOn = false } }
}

private fun statusText(s: UiState) = when (s.phase) {
    Phase.IDLE -> if (s.status.isNotEmpty()) s.status else "Orb dabakar bolein, ya neeche likhein"
    Phase.LISTENING -> "Sun raha hoon…"
    Phase.THINKING -> s.status.ifEmpty { "Soch raha hoon…" }
    Phase.SPEAKING -> "Bol raha hoon… (orb dabakar beech mein rok sakte hain)"
}

@Composable
fun AssistantScreen(vm: AppViewModel) {
    val s by vm.ui.collectAsState()
    val level by vm.level.collectAsState()
    val cfg by vm.settings.state.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val visible = s.messages.filter { it.role != Role.SYSTEM && !(it.role == Role.ASSISTANT && it.text.isBlank()) }
    LaunchedEffect(visible.size) { if (visible.isNotEmpty()) listState.animateScrollToItem(visible.lastIndex) }
    KeepScreenOn(s.handsFree)

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(cfg.assistantName, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.newChat() }) { Text("Nayi chat") }
        }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Orb(s.phase, level) { vm.onMicClick() } }
        Text(statusText(s), Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        if (s.partial.isNotEmpty()) Text("“${s.partial}”", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground)
        s.error?.let { e ->
            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(e, Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.dismissError() }) { Text("OK") }
                }
            }
        }
        if (visible.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Try karein:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                listOf("YouTube kholo", "Torch on karo", "Mere phone ki battery kitni hai?", "Mausam batao", "Aaj ki news batao").forEach { q ->
                    AssistChip(onClick = { vm.sendText(q) }, label = { Text(q) }, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(visible.size) { i -> MessageBubble(visible[i].role, visible[i].text, visible[i].toolName) }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = s.handsFree, onClick = { vm.toggleHandsFree() }, label = { Text("Hands-free (app khula ho tab)") })
            if (s.phase == Phase.SPEAKING) OutlinedButton(onClick = { vm.stopSpeaking() }) { Text("Stop") }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Yahan likhein…") }, maxLines = 3,
            )
            IconButton(onClick = { vm.sendText(input); input = "" }, enabled = input.isNotBlank()) { Icon(Icons.Filled.Send, contentDescription = "Send") }
            IconButton(onClick = { vm.onMicClick() }) { Text("🎤") }
        }
    }
}

@Composable
private fun MessageBubble(role: Role, text: String, toolName: String?) {
    when (role) {
        Role.TOOL -> Text("⚙ ${toolName ?: "tool"}: ${text.take(160)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Role.USER -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                Text(text, Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
        else -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                Text(text, Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel, onOpen: (String) -> Unit) {
    val list by vm.history.collectAsState()
    var q by remember { mutableStateOf("") }
    LaunchedEffect(q) { vm.refreshHistory(q) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Conversation history", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search…") }, singleLine = true)
        if (list.isEmpty()) Text("Koi saved conversation nahi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list.size) { i ->
                val c = list[i]
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), onClick = { onOpen(c.id) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.title.ifEmpty { "Chat" }, color = MaterialTheme.colorScheme.onSurface)
                            Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(c.updated)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { vm.deleteConversation(c.id, q) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete conversation") }
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionsScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val app = ctx.applicationContext as com.adai.assistant.AdAiApp
    val cfg by app.container.settings.state.collectAsState()
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { /* not persistable */ }
            app.container.settings.update { it.copy(fileTreeUri = uri.toString()) }
        }
    }
    fun granted(p: String) = tick >= 0 && ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun open(action: String) { try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { /* no such screen */ } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Permissions & integrations", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        Text("Permissions tab maangi jaati hain jab unki zaroorat hoti hai. Yahan se aap pehle se bhi de sakte hain.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        PermCard("Microphone", "Voice commands sunne ke liye. Sirf tab chalta hai jab aap orb dabate hain (ya hands-free on ho).", granted(Manifest.permission.RECORD_AUDIO), "Allow") { permLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        PermCard("Contacts", "Naam se call/SMS ke liye contact dhoondhna. Data phone se bahar nahi jaata.", granted(Manifest.permission.READ_CONTACTS), "Allow") { permLauncher.launch(Manifest.permission.READ_CONTACTS) }
        PermCard("Phone calls", "Confirmation ke baad seedha call lagane ke liye. Ye na dein to sirf dialer khulega.", granted(Manifest.permission.CALL_PHONE), "Allow") { permLauncher.launch(Manifest.permission.CALL_PHONE) }
        PermCard("Notification access", "Optional. Sirf app naam + title padhta hai (message content kabhi nahi). Android Settings mein aap khud on karte hain.",
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) && tick >= 0, "Open settings") { open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        PermCard("Accessibility service", "Optional. Back/Home dabana, screen text padhna, button tap karna — sirf aapke kehne par aur har baar confirmation ke baad. Banking/OTP screens par use na karein. Password fields kabhi nahi padhe jaate.",
            AdAccessibilityService.instance != null && tick >= 0, "Open settings") { open(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        PermCard("File search folder", if (cfg.fileTreeUri.isEmpty()) "Ek folder chunein; assistant sirf usi folder ke andar file names search karega." else "Authorized folder set hai.",
            cfg.fileTreeUri.isNotEmpty(), if (cfg.fileTreeUri.isEmpty()) "Choose folder" else "Change folder") { folderLauncher.launch(null) }
        if (cfg.fileTreeUri.isNotEmpty()) TextButton(onClick = { app.container.settings.update { it.copy(fileTreeUri = "") } }) { Text("Folder access hatayein") }
        PermCard("Hindi voice (TTS data)", "Agar Hindi bolne mein problem ho to phone ki Text-to-speech settings mein Hindi voice data install karein.", null, "Open TTS settings") { open("com.android.settings.TTS_SETTINGS") }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Honest limits", color = MaterialTheme.colorScheme.primary)
                Text("• Wake word / app band hone par sunna: NAHI banaya gaya. Hands-free sirf tab chalta hai jab app khula ho (screen on).", style = MaterialTheme.typography.bodySmall)
                Text("• SMS apne aap nahi bheji jaati — draft khulta hai, send aap dabate hain.", style = MaterialTheme.typography.bodySmall)
                Text("• Wi-Fi/Bluetooth toggle: Android apps ko allow nahi karta; settings page khulta hai.", style = MaterialTheme.typography.bodySmall)
                Text("• Calendar, Email, Smart-home: planned, abhi implemented nahi.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PermCard(title: String, why: String, ok: Boolean?, action: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                if (ok != null) Text(if (ok) "✓ On" else "Off", color = if (ok) JarvisGreen else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(why, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (ok != true || title.contains("folder", true) || title.contains("TTS")) OutlinedButton(onClick = onClick) { Text(action) }
        }
    }
}
