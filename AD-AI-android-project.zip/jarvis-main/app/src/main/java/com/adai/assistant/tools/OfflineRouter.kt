package com.adai.assistant.tools

import org.json.JSONObject

data class OfflineAction(val tool: String, val args: JSONObject)

/**
 * Deterministic fast-path for a few unambiguous device commands (Hindi / English / Hinglish).
 * Works with no internet and no API key. Anything not clearly matched returns null and goes to the AI.
 */
object OfflineRouter {
    private val torchWords = listOf("torch", "flashlight", "flash light", "टॉर्च", "टार्च", "फ्लैशलाइट")
    private val offWords = listOf(" off", "band", "बंद", "बन्द", "bujha", "बुझा")
    private val onWords = listOf(" on", "chalu", "चालू", "jala", "जला", "start")
    private val batteryWords = listOf("battery", "बैटरी", "charge kitna", "charging")
    private val timeWords = listOf("kitne baje", "what time", "time kya", "current time", "कितने बजे", "टाइम क्या", "समय क्या")

    val aliases = mapOf(
        "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "कैमरा" to "camera", "गूगल" to "google", "क्रोम" to "chrome", "जीमेल" to "gmail", "मैप्स" to "maps",
        "फोन" to "phone", "सेटिंग्स" to "settings", "इंस्टाग्राम" to "instagram", "टेलीग्राम" to "telegram",
    )

    private val openPrefix = Regex("^(?:open|launch|start)\\s+(.+)$")
    private val openSuffix = Regex("^(.+?)\\s+(?:kholo|khol do|khol de|khol|open karo|open kar do|chalao|chala do|खोलो|खोल दो|खोलिए|चलाओ|चालू करो)$")

    fun route(raw: String): OfflineAction? {
        val t = " " + raw.lowercase().trim().trimEnd('.', '!', '?', '।')
        val text = t.trim()
        if (text.isEmpty() || text.split(" ").size > 8) return null

        if (torchWords.any { t.contains(it) }) {
            val off = offWords.any { t.contains(it) }
            val on = onWords.any { t.contains(it) }
            if (off) return OfflineAction("flashlight", JSONObject().put("on", false))
            if (on) return OfflineAction("flashlight", JSONObject().put("on", true))
            return null
        }
        if (batteryWords.any { t.contains(it) } && !t.contains("saver")) return OfflineAction("battery_status", JSONObject())
        if (timeWords.any { t.contains(it) }) return OfflineAction("get_datetime", JSONObject())

        val name = openPrefix.find(text)?.groupValues?.get(1) ?: openSuffix.find(text)?.groupValues?.get(1)
        if (name != null) {
            var n = name.trim().removeSuffix(" app").trim()
            n = aliases[n] ?: n
            if (n.isNotEmpty() && n.length <= 30 && n.split(" ").size <= 3) return OfflineAction("open_app", JSONObject().put("name", n))
        }
        return null
    }
}
