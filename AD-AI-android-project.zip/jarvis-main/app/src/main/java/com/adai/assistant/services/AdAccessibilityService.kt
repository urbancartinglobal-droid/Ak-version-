package com.adai.assistant.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Opt-in service. Does nothing unless a tool is invoked (with user confirmation). Never records or logs screen content. */
class AdAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    fun navigate(action: String): Boolean = performGlobalAction(
        when (action) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            else -> return false
        },
    )

    fun readScreenText(limit: Int = 3000): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collect(root, sb, limit)
        return sb.toString().trim()
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder, limit: Int) {
        if (n == null || sb.length >= limit) return
        if (n.isPassword) return // never read password fields
        val t = n.text?.toString()?.takeIf { it.isNotBlank() } ?: n.contentDescription?.toString()?.takeIf { it.isNotBlank() }
        if (t != null) sb.append(t).append('\n')
        for (i in 0 until n.childCount) collect(n.getChild(i), sb, limit)
    }

    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (node in root.findAccessibilityNodeInfosByText(label)) {
            if (node.isPassword) continue
            var cur: AccessibilityNodeInfo? = node
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    companion object {
        @Volatile var instance: AdAccessibilityService? = null
    }
}
