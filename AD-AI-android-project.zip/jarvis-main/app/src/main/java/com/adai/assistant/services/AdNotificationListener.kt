package com.adai.assistant.services

import android.app.Notification
import android.service.notification.NotificationListenerService

/** Opt-in. Only exposes app name + title of non-message notifications; message/email content is never exposed. */
class AdNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }

    fun snapshot(): List<String> {
        val pm = packageManager
        val active = activeNotifications ?: return emptyList()
        return active.take(25).map { sbn ->
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (e: Exception) { sbn.packageName }
            val n = sbn.notification
            val sensitive = n.category == Notification.CATEGORY_MESSAGE || n.category == Notification.CATEGORY_EMAIL
            if (sensitive) "$app: (naya message — content hidden)"
            else "$app: ${n.extras?.getCharSequence(Notification.EXTRA_TITLE) ?: "(no title)"}"
        }
    }

    companion object {
        @Volatile var instance: AdNotificationListener? = null
    }
}
