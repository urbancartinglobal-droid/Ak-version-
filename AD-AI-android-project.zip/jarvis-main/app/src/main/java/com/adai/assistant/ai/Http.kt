package com.adai.assistant.ai

import com.adai.assistant.core.AiError
import com.adai.assistant.core.NetworkException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

data class HttpResult(val code: Int, val body: String)

object Http {
    const val USER_AGENT = "ADAI/0.1 (Android personal assistant)"

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .callTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    /** Executes a request. Throws [NetworkException] for connectivity problems. */
    suspend fun execute(req: Request): HttpResult = withContext(Dispatchers.IO) {
        try {
            client.newCall(req).execute().use { HttpResult(it.code, it.body?.string().orEmpty()) }
        } catch (e: UnknownHostException) {
            throw NetworkException("Internet nahi hai ya server tak pahunch nahi paaye. (No internet / host not found.)")
        } catch (e: SocketTimeoutException) {
            throw NetworkException("Server ne samay par jawab nahi diya. (Timeout.)")
        } catch (e: IOException) {
            throw NetworkException("Network error: ${e.javaClass.simpleName}")
        }
    }

    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): HttpResult {
        val b = Request.Builder().url(url).header("User-Agent", USER_AGENT)
        headers.forEach { (k, v) -> b.header(k, v) }
        return execute(b.build())
    }

    suspend fun postJson(url: String, json: JSONObject, headers: Map<String, String>): HttpResult {
        val b = Request.Builder().url(url).header("User-Agent", USER_AGENT)
            .post(json.toString().toRequestBody("application/json".toMediaType()))
        headers.forEach { (k, v) -> b.header(k, v) }
        return execute(b.build())
    }
}

/** Maps an HTTP failure from an AI provider to a user-presentable [AiError]; redacts the key. */
fun mapHttpError(code: Int, body: String, model: String, apiKey: String): AiError {
    val lower = body.lowercase()
    fun detail(): String {
        val msg = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) { "" }
        val raw = msg.ifEmpty { body.take(200) }
        return if (apiKey.isNotEmpty()) raw.replace(apiKey, "***") else raw
    }
    return when {
        code == 401 || code == 403 -> AiError.InvalidKey()
        code == 402 -> AiError.OutOfCredits()
        code == 429 && (lower.contains("insufficient_quota") || lower.contains("billing") || lower.contains("credit")) -> AiError.OutOfCredits()
        code == 429 -> AiError.RateLimited()
        code == 404 -> AiError.ModelNotFound(model)
        code == 400 && (lower.contains("api key not valid") || lower.contains("api_key_invalid")) -> AiError.InvalidKey()
        else -> AiError.Server(code, detail())
    }
}
