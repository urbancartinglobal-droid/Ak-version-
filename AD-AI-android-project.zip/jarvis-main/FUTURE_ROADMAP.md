# Roadmap
1. Compile, run on a device, fix issues found (first priority).
2. Foreground-service wake word (e.g. Porcupine/openWakeWord) with visible notification and battery guidance.
3. Real reminders (AlarmManager + notification channel) instead of Clock-app alarms.
4. Calendar (CalendarContract) and email (Gmail API / mailto drafts) tools.
5. Image understanding: camera/gallery picker → multimodal request.
6. Document understanding: pick PDF/text → summarise.
7. Routines: JSON list of tool steps triggered by phrases (extends custom commands).
8. Sports API provider; in-app directions provider.
9. Room database + full-text search; migrate `ItemStore`/`ConversationStore`.
10. Gemini Live (streaming audio) mode — the original Python project's approach — as an alternate voice backend.
11. Default-assistant integration (VoiceInteractionService).
12. Plugin/tool packaging; Hilt DI; Play-policy review of accessibility usage.
