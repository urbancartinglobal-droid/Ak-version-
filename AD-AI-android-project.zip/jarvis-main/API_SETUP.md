# API setup

An API key from one provider does not work with another. Choose the matching provider in Settings → AI Brain.

## Google Gemini (default)
1. Create a key in Google AI Studio (aistudio.google.com → "Get API key").
2. App → Settings → AI Brain → provider **Google Gemini** → model (default `gemini-2.5-flash`; check Google's docs for current names)
   → paste key → **Save** → **Test connection**.
The key is sent in the `x-goog-api-key` header over HTTPS, never in a URL.

## OpenAI-compatible (OpenAI, Groq, OpenRouter, …)
Choose **OpenAI-compatible**, pick a preset (or enter any base URL ending in `/v1`), set the model name your provider offers, paste
that provider's key, Save, Test connection. The provider must support tool/function calling for phone control to work.

## Web search (optional): Tavily
Settings → Live Data → paste a Tavily key. Needed only for web search (sports scores, product prices, government info).
Weather (Open-Meteo), news (Google News RSS), currency (Frankfurter/ECB) and Wikipedia need no key.

## Backend
No backend is required: the key lives encrypted on your phone and the app calls the provider directly. Trade-off: anyone who extracts
the key from a rooted phone could use it. If you ever distribute the app to others, put a server proxy in front of the provider
instead of shipping keys.

## Errors you may see
Invalid/expired key, out of credits/quota, rate limit, model not found, no internet and timeouts each show a specific message.
