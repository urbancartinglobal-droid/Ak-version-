# Features status

**Legend:** ✅ implemented in source · 🧪 unit-tested in source (tests written, NOT yet executed) · 📱 needs real-device testing · ⚙ needs your config · ⛔ not implemented.
**Nothing has been compiled or run yet** (no Android SDK/network in the authoring environment). Treat every ✅ as "written, unverified".

| Feature | Status |
|---|---|
| Chat UI, history, search, delete | ✅ 🧪(storage) 📱 |
| Gemini + OpenAI-compatible providers, tool calling | ✅ 🧪(against fake HTTP server) ⚙ key |
| API key save/replace/delete (encrypted), Test connection | ✅ 📱 |
| Provider error messages (bad key, credits, rate limit, offline) | ✅ 🧪 |
| Speech-to-text (hi-IN/en-IN/en-US), error messages | ✅ 📱 |
| Text-to-speech, language/voice/speed/pitch, interrupt | ✅ 🧪(helpers) 📱 |
| Hands-free loop (while app open, screen on) | ✅ 📱 |
| Always-on wake word / works when app closed | ⛔ not implemented (needs foreground service + wake-word engine; battery/mic limits) |
| Open apps, camera, settings pages, dialer, contacts, maps, URLs, share | ✅ 📱 |
| Call (confirm → CALL_PHONE, else dialer) | ✅ 📱 |
| SMS | ✅ draft only; sending is always by you ✋ (no silent SMS) |
| Alarm / timer / reminder | ✅ via Clock app; Android gives no success callback, so result is worded as "request sent" 📱 |
| Flashlight (verified via TorchCallback), volume (read-back verified), battery, network | ✅ 📱 |
| Wi-Fi/Bluetooth/airplane toggles | ⛔ not permitted by Android; settings page opens instead |
| Notes, memory (user-controlled) | ✅ 🧪 |
| Calculator | ✅ 🧪 |
| Offline quick commands + custom commands | ✅ 🧪(router) |
| File search in one authorized folder | ✅ 📱 |
| Notification access (titles only), accessibility (back/home/read/tap) | ✅ 📱 opt-in |
| Weather (Open-Meteo), News (Google News RSS), Currency (Frankfurter), Wikipedia | ✅ 🧪(parsers) — endpoints not verified from here |
| Web search / sports / product prices / gov info | ✅ via Tavily ⚙ key (snippets + links) |
| Dedicated sports API, maps directions in-app | ⛔ (maps opens Google Maps; sports via web search) |
| Calendar event (opens pre-filled form; you tap Save), email draft (you tap Send) | ✅ 📱 |
| Routines (custom command type: `open_app:YouTube; flashlight:on; volume:up; settings:wifi; open_url:…`) | ✅ 📱 |
| Smart-home, image/camera understanding, document understanding, configurable wake word, plugins | ⛔ planned (architecture ready: add a `Tool`) |
| Release signing | ⚙ you provide keystore |
