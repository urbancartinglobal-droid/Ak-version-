# AD AI — Android Jarvis-style assistant

Native Android app (Kotlin + Jetpack Compose). Hindi-first voice + text assistant that talks to an LLM of your choice
(Google Gemini or any OpenAI-compatible API), can control parts of your phone through documented Android APIs, and
fetches live information (weather, news, currency, Wikipedia, web search).

> **Status: source complete, NOT yet compiled or run.** The environment this was written in had no Android SDK/Gradle/network.
> Build it with Android Studio or the included GitHub Actions workflow (see BUILD_INSTRUCTIONS.md) and read FEATURES_STATUS.md
> for what is verified (nothing on-device yet) versus implemented.

## Origin
Started from `jarvis-main.zip` — a Python desktop script using the Gemini Live API (PyAudio). The original files are kept in
`legacy/`. The Android app keeps the same ideas (Gemini, Hindi, voice-first) but is a new native implementation.
The old "girlfriend Maya" persona prompt was NOT carried over as default; you can paste any personality in Settings → Custom.

## Architecture (package `com.adai.assistant`)
| Package | Responsibility |
|---|---|
| `ai/` | `AiProvider` interface; `GeminiProvider`, `OpenAiCompatibleProvider`; `ProviderFactory` (register new providers here) |
| `core/` | Models, `Orchestrator` (model↔tool loop), `Prompts` |
| `tools/` | `Tool` + `ToolRegistry`; phone tools, live tools, misc tools, `OfflineRouter`, `Calc`, `TorchController` |
| `live/` | `LiveData` providers (Open-Meteo, Google News RSS, Frankfurter/ECB, Wikipedia, Tavily) with TTL cache |
| `voice/` | `SpeechInput` (SpeechRecognizer), `SpeechOutput` (TextToSpeech) |
| `settings/` | `SettingsStore` — API keys in EncryptedSharedPreferences |
| `data/` | JSON-file stores: conversations, memory, notes, custom commands |
| `services/` | Opt-in `AdAccessibilityService`, `AdNotificationListener` |
| `ui/` | Compose screens, `AppViewModel` (voice flow, confirmations, permissions) |

## Add a new tool
Add a `tool(name, description, params) { args, ctx -> ToolResult }` entry to one of the lists in `tools/*.kt`. It is automatically
exposed to the model. Return `ToolResult.fail(...)` honestly when something can't be confirmed.

## Add a new AI provider / live-data source
Implement `AiProvider` and register it in `ProviderFactory`; add a method to `LiveData` and a tool in `LiveTools.kt`.
