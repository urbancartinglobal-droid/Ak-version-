# Permissions

| Permission / access | Why | When asked |
|---|---|---|
| INTERNET, ACCESS_NETWORK_STATE | AI + live data, connectivity info | install-time (normal) |
| SET_ALARM | Create alarms/timers via Clock app | install-time (normal) |
| RECORD_AUDIO | Voice input | first mic tap, with explanation |
| READ_CONTACTS | Find a contact by name for call/SMS | first time needed, with explanation |
| CALL_PHONE | Place a call after you confirm; else only the dialer opens | first call |
| Notification access (Settings) | `read_notifications`: app name + title only, never message bodies | you enable it manually |
| Accessibility service (Settings) | Back/Home, read visible non-password text, tap by label — each use needs confirmation | you enable it manually |
| Folder access (file picker) | File-name search inside ONE folder you pick | Permissions screen |

Not requested: SMS send, location, storage-wide, camera, QUERY_ALL_PACKAGES, background microphone, overlay.

Notes
* Accessibility: transparent and opt-in; text read from screen is sent to your AI provider after your confirmation. Do not use on banking/OTP
  screens. Google Play restricts non-accessibility uses of this API; this is fine for sideloading, risky for a Play Store listing.
* The app never bypasses the lock screen, sandboxing or permission prompts, and does not claim root-level control.
