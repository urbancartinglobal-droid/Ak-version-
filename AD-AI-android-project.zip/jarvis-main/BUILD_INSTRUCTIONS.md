# Building AD AI

Requirements: JDK 17, Android SDK (platform 34, build-tools), Gradle 8.7+ (Android Studio bundles all of this).

## Option A — Android Studio (easiest)
1. Install Android Studio (Koala or newer). File → Open → select this folder.
2. Let Gradle sync (it downloads dependencies; internet required).
3. Build → Build Bundle(s)/APK(s) → Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Option B — Command line
This repo has `gradle/wrapper/gradle-wrapper.properties` but not the wrapper JAR/scripts (they cannot be generated offline). Once:
```
gradle wrapper --gradle-version 8.7      # needs Gradle installed once
./gradlew :app:testDebugUnitTest          # run unit tests
./gradlew :app:assembleDebug              # build debug APK
```
**Rebuild after any code change:** `./gradlew :app:assembleDebug`

## Option C — GitHub Actions (no local setup)
Push this folder to a GitHub repo. `.github/workflows/build-apk.yml` runs unit tests, builds the debug APK and uploads it as the
artifact `AD-AI-debug-apk` (Actions tab → latest run → Artifacts).

## Release APK
Create a keystore (`keytool -genkeypair -v -keystore adai.jks -alias adai -keyalg RSA -keysize 2048 -validity 10000`), then set
`ADAI_KEYSTORE`, `ADAI_KEYSTORE_PASSWORD`, `ADAI_KEY_ALIAS`, `ADAI_KEY_PASSWORD` in `~/.gradle/gradle.properties` or env, and run
`./gradlew :app:assembleRelease` → `app/build/outputs/apk/release/app-release.apk`. Without these the release APK is unsigned and
cannot be installed. Never commit the keystore (it is git-ignored).

## Install on your phone
1. Copy the APK to the phone (or download the Actions artifact there).
2. Open it; allow "Install unknown apps" for your file manager/browser when asked.
3. Open **AD AI**. (Or with USB debugging: `adb install -r app-debug.apk`.)

## Updating
Increase `versionCode`/`versionName` in `app/build.gradle.kts`, rebuild, install over the old APK (same signing key required).
